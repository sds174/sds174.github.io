<?php
/*
Plugin Name: Contact Us Request
Description: A custom contact request form plugin for Alphacom
Version:     1.0.0
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'wp-load.php');
require_once( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'ajax.php' );
require_once( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'settings.php' );
require_once( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes/class.rhl_git_register.php' );

register_activation_hook(__FILE__, ['rhl_git_register','rhl_git_install']); 
register_deactivation_hook(__FILE__, ['rhl_git_register','rhl_git_uninstall']); 
register_uninstall_hook(__FILE__, ['rhl_git_register','rhl_git_uninstall']); 

add_action('plugins_loaded', array( 'rhl_git_register', 'init' ));

require_once( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes/class.rhl_git_getintouch_request.php' );

function getintouch_request_form_shortcode() {
    ob_start();
    $quote = new rhl_git_getintouch_request();
    $quote->loadForm();
    return ob_get_clean();
}

add_shortcode( 'contact_us_request', 'getintouch_request_form_shortcode' );
?>