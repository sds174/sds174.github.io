<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'wp-load.php');
//Remove Contact Request
	add_action( 'wp_ajax_nopriv_rhl_git_remove', 'rhl_git_remove' );
	add_action( 'wp_ajax_rhl_git_remove', 'rhl_git_remove' );
//end
//contact request submission
	add_action( 'wp_ajax_nopriv_rhl_git_get_in_touch_form_submission', 'rhl_git_get_in_touch_form_submission' );
	add_action( 'wp_ajax_rhl_git_get_in_touch_form_submission', 'rhl_git_get_in_touch_form_submission' );
//end

//delete
	function rhl_git_remove(){
		$id = trim($_POST['id']);
		$nm_query = new rhl_git_data_query;
		$rec = $nm_query->removeById($id);
		if(!$rec){
			echo json_encode(['status' => 'error', 'message' => 'Record could not be deleted!']);exit;
		}
		echo json_encode(['status' => 'success', 'message' => 'Record deleted successfully!']);exit;
	}
//end
// old working function
// function rhl_git_get_in_touch_form_submission() {

// 	$data = [];
//     // sanitize user form input	   
// 	$data['gt_fname'] 							= sanitize_text_field( $_POST['gt_fname'] );
// 	$data['gt_email'] 							= sanitize_text_field( $_POST['gt_email'] ); 
// 	$data['gt_phone'] 							= sanitize_text_field( $_POST['gt_phone'] );	
// 	$data['ar_message'] 						= sanitize_text_field( $_POST['ar_message'] );
	
// 	$data['added_on']							= date('Y-m-d h:i:s');

//     //Validate the data     
//     get_in_touch_form_validation($data);

// 	//Save the data and send emails	 
//     complete_get_in_touch_form($data);
// } 
// old working function
	// new function 
function rhl_git_get_in_touch_form_submission() {

	
	if(isset($_POST['recaptcha_token']) && !empty($_POST['recaptcha_token'])) {
		$secretKey = '6Lfa_ScqAAAAAO2PhNsbkNxwmEhNpU8wqtrvVJ8b';
		$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$_POST['recaptcha_token']);
		$response = json_decode($verifyResponse); 
		if($response->success == 1){
			 $data = [];
             $data['gt_fname'] 							= sanitize_text_field( $_POST['gt_fname'] );
	         $data['gt_email'] 							= sanitize_text_field( $_POST['gt_email'] ); 
	         $data['gt_phone'] 							= sanitize_text_field( $_POST['gt_phone'] );	
	         $data['ar_message'] 						= sanitize_text_field( $_POST['ar_message'] );
	         $data['added_on']							= date('Y-m-d h:i:s');
     
             get_in_touch_form_validation($data);
             complete_get_in_touch_form($data);
		}
		   
    }
	else {
		echo '<p>Error: reCAPTCHA validation failed. Please try again.</p>';
	}	
	// print_r($response);
}  
	// new function
//Server side validation
function get_in_touch_form_validation($data = []){
	global $form_errors;
	$form_errors = new WP_Error;
	//print_r($data);
	//validating the input received as argument
	if (
		empty( $data['gt_fname'] )		|| 
		empty( $data['gt_email'] )		||
		empty( $data['gt_phone'] )  	||
		empty( $data['ar_message'] )
	){
		$form_errors->add('field', 'Input data is not properly entered, please try again');
	}
}

function complete_get_in_touch_form($data = []){

	global 	$wpdb,
			$form_errors; 
    if(count( $form_errors->errors) > 0){
    	echo json_encode(['status' => false, 'message' => 'Input data is not properly entered, please try again']);exit;
    }   

    $success = get_option('rhl_git_success');
	$error = get_option('rhl_git_error');
	
	$ip = '';
	if(!empty($_SERVER['HTTP_CLIENT_IP'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    $data['ip_addr'] = !empty($ip) ? $ip : 'NULL';
    $query = $wpdb->insert( $wpdb->prefix.'contact_us_requests', $data);

   // print_r($query);exit;

    if(!$query){
    	echo json_encode(['status' => false, 'message' => $error]);exit;
    }

     rhl_git_send_user_email($data);
     rhl_git_send_admin_email($data);
	
    echo json_encode(['status' => true, 'message' => $success]);
	exit;

}

// //Email Template
function rhl_git_send_user_email($data = []){
	$mail 			= new SendEmail;	
	$from 			= get_option('rhl_git_email_from');
	$to 			= $data['gt_email'];
	$subject 		= get_option('rhl_git_user_email_subject');
	$template_body 	= get_option('rhl_git_user_email_body');
	$full_name 		= $data['gt_fname'];

	$template_body 	= str_replace("{full_name}",$full_name,$template_body);
	$template_body 	= str_replace("{email}",$data['gt_email'],$template_body);
	$template_body 	= str_replace("{phone}",$data['gt_phone'],$template_body);	
	$template_body 	= str_replace("{message}",$data['ar_message'],$template_body);
	$template_body 	= str_replace("{ip}",$data['ip_addr'],$template_body);

	$body 			= $mail->template($template_body);
	
	$headers 		= [
		'Content-Type: text/html; charset=UTF-8',
		'From: '.$from
	];

	wp_mail( $to, $subject, $body, $headers );		
}	

//Admin Email Template
function rhl_git_send_admin_email($data = []){
	$mail 			= new SendEmail;	
	$from 			= get_option('rhl_git_email_from');
	$to 			= get_option('rhl_git_email_to');
	$cc 			= get_option('rhl_git_email_cc');
	$subject 		= get_option('rhl_git_admin_email_subject');
	$template_body 	= get_option('rhl_git_admin_email_body');
	$full_name 		= $data['gt_fname'];

	$template_body 	= str_replace("{full_name}",$full_name,$template_body);
	$template_body 	= str_replace("{email}",$data['gt_email'],$template_body);
	$template_body 	= str_replace("{phone}",$data['gt_phone'],$template_body);	
	$template_body 	= str_replace("{message}",$data['ar_message'],$template_body);
	$template_body 	= str_replace("{ip}",$data['ip_addr'],$template_body);

	$body 			= $mail->template($template_body);
	$headers 		= [
		'Content-Type: text/html; charset=UTF-8',
		'From: '.$from, 
    	'Cc: '.$cc, 
    	'Bcc:'.$bcc, 
    	'Reply-To: '.$data["full_name"].' <'.$data["email"].'>'
	];

	wp_mail( $to, $subject, $body, $headers );
}
?>