jQuery(document).ready(function () {
	// add for recaptcha

	// add for recaptcha
	//Form validation
	jQuery.validator.addMethod("customemail", function (value, element, params) {
		var re = /^[a-z0-9]+([-._][a-z0-9]+)*@([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,4}$/;
		return re.test(value);
	}, "Please enter a valid email address.");

	jQuery.validator.addMethod("nameRegex", function (value, element) {
		return this.optional(element) || /^[a-zA-Z\ , .!'\s]+$/i.test(value);
	}, "Please enter only alphabetic characters.");

	jQuery('#gt_phone').on('input', function () {
		var value = jQuery(this).val();
		// Remove all characters except digits and the leading '+'
		var sanitized = value.replace(/(?!^\+)[^0-9]/g, '');
		// Ensure only one leading '+'
		if (sanitized.charAt(0) === '+') {
			sanitized = '+' + sanitized.substring(1).replace(/\+/g, '');
		}
		jQuery(this).val(sanitized);
	});
	// Add pattern method to jQuery Validate if not already present
	if (!jQuery.validator.methods.pattern) {
		jQuery.validator.addMethod("pattern", function (value, element, param) {
			if (this.optional(element)) {
				return true;
			}
			if (typeof param === "string") {
				param = new RegExp(param);
			}
			return param.test(value);
		}, "Invalid format.");
	}

	jQuery("#gt_fname,#gt_lname,#ar_message").keypress(function (e) {
		if (e.which === 32 && !this.value.length) {
			e.preventDefault();
		}
	});

	jQuery('#get_in_touch').validate({
		errorElement: "i",
		errorClass: "error",
		ignore: '',
		rules: {
			gt_fname: {
				required: true,
				nameRegex: true,
				minlength: 2
			},
			gt_phone: {
				required: true,
				//minlength: 6,
				maxlength: 14,
				pattern: /^(\+?\d{1,3})?\d{6,12}$/
			},
			gt_email: {
				required: true,
				customemail: true
			},
			ar_message: {
				required: true,
				minlength: 2
			}

		},
		messages: {
			gt_fname: {
				required: "Please enter your full name",
				minlength: "Full name should contain minimum two characters"
			},

			gt_email: {
				required: "Please enter your email address",
				customemail: "Please enter your valid email address"
			},

			gt_phone: {
				required: "Please enter your mobile number",
				//minlength: "Phone number must be of minimum 6 digits",
				maxlength: "Phone number must be of maximum 14 digits",
				pattern: "Please enter a valid phone number"
			},

			ar_message: {
				required: "Please enter your message",
				minlength: "Minimum add two characters"
			}
		},
		 
		// Another submit handelar function
		submitHandler: function (form) {
			show_loader(form);
			jQuery("#rhl_git_sbmt_btn").prop('disabled', true);
			jQuery("#rhl_git_sbmt_btn").text('Please wait');
 			 
			  grecaptcha.ready(function() {
				grecaptcha.execute('6Lfa_ScqAAAAAIgYlTBuDtAum5tY9y-_DPNE3L36', {action: 'submit'}).then(function(token) {
				let allData = new FormData(form);
				allData.append('action', 'rhl_git_get_in_touch_form_submission');
				allData.append('recaptcha_token', token);  // Append the reCAPTCHA token

				jQuery.ajax({
					url: rhl_git_form_submission.ajax_url,
					type: 'POST',
					data: allData,
					dataType: "json",
					cache: false,
					processData: false,
					contentType: false,
					success: function (response) {
						jQuery("#rhl_git_sbmt_btn").prop('disabled', false);
						jQuery("#rhl_git_sbmt_btn").html('<span>Submit</span><svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.073 6.49999H0.5C0.357667 6.49999 0.23875 6.45224 0.14325 6.35674C0.0477499 6.26124 0 6.14232 0 5.99999C0 5.85765 0.0477499 5.73874 0.14325 5.64324C0.23875 5.54774 0.357667 5.49999 0.5 5.49999H12.073L8.3385 1.76549C8.241 1.66799 8.19 1.55324 8.1855 1.42124C8.181 1.28907 8.232 1.1679 8.3385 1.05774C8.44867 0.947404 8.56758 0.891322 8.69525 0.889488C8.82275 0.887488 8.94167 0.941655 9.052 1.05199L13.4345 5.43449C13.5218 5.52182 13.5831 5.61099 13.6182 5.70199C13.6536 5.79299 13.6712 5.89232 13.6712 5.99999C13.6712 6.10765 13.6536 6.20699 13.6182 6.29799C13.5831 6.38899 13.5218 6.47815 13.4345 6.56549L9.052 10.948C8.9545 11.0455 8.83875 11.0965 8.70475 11.101C8.57075 11.1055 8.44867 11.0526 8.3385 10.9422C8.232 10.8321 8.17783 10.7142 8.176 10.5885C8.174 10.4628 8.22817 10.3448 8.3385 10.2345L12.073 6.49999Z" fill="#ff8a00"></path></svg>');
						jQuery('#get_in_touch')[0].reset();
						hide_loader(form);
						show_message(response, form);
						//window.location.href = "/thank-you-page/";
					},
					error: function (xhr) {
						hide_loader(form);
						console.log(xhr.responseText);
					}
				  });
			    });
			})
			
		}
		// Another submit handelar function
	});
})

//show the loader
function show_loader(form) {
	jQuery(form).find('.btn-submit').attr('disabled', true).val('Please Wait');
}
//hide the loader
function hide_loader(form) {
	jQuery(form).find('.btn-submit').attr('disabled', false).val('Submit');

}