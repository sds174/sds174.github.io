<form action="javascript:" class="form-style contact_frm allForm" id="get_in_touch">
    <div class="form-element">
        <label class="form-label" aria-label="Full name">Full Name*</label>
        <input name="gt_fname" id="gt_fname" type="text" class="form-field" autocomplete="off">
    </div>
    <div class="form-element">
        <label class="form-label" aria-label="Email">Email*</label>
        <input name="gt_email" type="text" class="form-field">
    </div>
    <div class="form-element">
        <label class="form-label" aria-label="Phone">Phone*</label>
        <input name="gt_phone" type="text" id="gt_phone" class="form-field">
    </div>
    <div class="form-element">
        <label class="form-label" aria-label="Write your message">Write your message*</label>
        <textarea class="form-field" name="ar_message" id="ar_message"></textarea>
    </div>
    <div class="form-element mb-0 text-right">
        <button type="submit" class="btn dnt_btn btn-submit c2a c--mbBlack c2a--inline" aria-label="Submit" id="rhl_git_sbmt_btn">
            <span>Submit</span>
            <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12.073 6.49999H0.5C0.357667 6.49999 0.23875 6.45224 0.14325 6.35674C0.0477499 6.26124 0 6.14232 0 5.99999C0 5.85765 0.0477499 5.73874 0.14325 5.64324C0.23875 5.54774 0.357667 5.49999 0.5 5.49999H12.073L8.3385 1.76549C8.241 1.66799 8.19 1.55324 8.1855 1.42124C8.181 1.28907 8.232 1.1679 8.3385 1.05774C8.44867 0.947404 8.56758 0.891322 8.69525 0.889488C8.82275 0.887488 8.94167 0.941655 9.052 1.05199L13.4345 5.43449C13.5218 5.52182 13.5831 5.61099 13.6182 5.70199C13.6536 5.79299 13.6712 5.89232 13.6712 5.99999C13.6712 6.10765 13.6536 6.20699 13.6182 6.29799C13.5831 6.38899 13.5218 6.47815 13.4345 6.56549L9.052 10.948C8.9545 11.0455 8.83875 11.0965 8.70475 11.101C8.57075 11.1055 8.44867 11.0526 8.3385 10.9422C8.232 10.8321 8.17783 10.7142 8.176 10.5885C8.174 10.4628 8.22817 10.3448 8.3385 10.2345L12.073 6.49999Z" fill="#ff8a00"></path>
            </svg>
        </button>
    </div>
</form> 
