<?php
/*
* Template Name: Product Listing Page
*/
get_header();
?> 
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash">Wide-Ranging Products</p>
                    <h1><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-2.png" alt="Curepoxy" title="Curepoxy" class="invert"></h1>
                </div>
            </div>
        </div>
    </section>

    <section class="product__listings bg--nadkarniWhite pt-2 mb-0">
        <div class="main-container">
            <div class="inner-container flow-rootX2">
                <div class="nadkarni__filter">
                    <p class="h7 text-uppercase">Filter By</p>
                    <form class="form-style grid grid--5 gap:1rem">
                        <div class="form-element form-select">
                            <select class="form-field">
                                <option value="">Product Group</option>
                            </select>
                        </div>
                        <div class="form-element form-select">
                            <select class="form-field">
                                <option value="">Select Type</option>
                            </select>
                        </div>
                        <div class="form-element form-select">
                            <select class="form-field">
                                <option value="">Bio-Based Content</option>
                            </select>
                        </div>
                        <div class="form-element form-select">
                            <select class="form-field">
                                <option value="">Availability</option>
                            </select>
                        </div>
                        <div class="form-element form-select">
                            <select class="form-field">
                                <option value="">Market</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="product__count">
                    <p class="h8">16 Products Found</p>
                    <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="compare.php">
                        <span class="material-icons-outlined">sync_alt</span>
                        <span class="text-uppercase">Compare Product (02)</span>
                    </a>
                </div>
                <div class="product__blocks grid grid--4 gap:1rem">
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__4">                     
                        <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                        <article class="flow-rootx2 c2a-parent">
                            <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                            <p class="h7">Phenalkamine</p>
                            <p class="h8 product__desc">Low viscosity, solvent-free and 
                                    fumeless Phenalkamine Resin for
                                    high-performance applications  ...</p>
                            <div class="c2a__grid__container pt-1">
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                    <span class="material-icons-outlined">sync_alt</span>
                                    <span class="text-uppercase">Compare</span>
                                </a>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>