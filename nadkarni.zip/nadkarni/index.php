<?php
/*
* Template Name: Blog
*/

//header
get_header();
?>
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash">You may also like</p>
                    <h1 class="h1">Insights</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="insights__listings bg--nadkarniWhite pt-2 mb-0">
        <div class="main-container">
            <div class="inner-container flow-rootX2">
                
                <div class="grid grid--4 gap:1-5rem">
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>
                    <div class="card__3 flow-rootX2">
                        <a href="insight-details.php"><figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure></a>
                        <article class="flow-rootX2">
                            <div class="tag">
                                <span class="h9">Blog Category</span>
                                <date class="h8">June 15. 2022</date>
                            </div>
                            <div class="description flow-rootx3">
                                <p class="h6">Title of the blog</p>
                                <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                    et dolore magna aliqua. </p>
                                <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    </div>                  
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>