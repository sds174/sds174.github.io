<?php
/*
* Template Name: Compare Page
*/
get_header();
?> 
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash">Wide-Ranging Products</p>
                    <h1 class="h1XL c--nadkarniDarkRed text-uppercase fw--l">Product Comparison</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="nadkarni__product__compare bg--nadkarniWhite pt-3 pb-3 mb-0">
        <div class="main-container">
            <div class="inner-container">
                <div class="product__compare">
                    <div class="compare__head">
                        <div class="compare__row">
                            <div class="compare-name">
                                <p class="h6l">Compare Cure Poxy 8040 vs others</p>
                                <p class="h9 fw--t">4 Items</p>
                            </div>
                            <div class="column">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/product-2.jpg" alt="Cure Poxy" title="Cure Poxy">
                                </figure>
                                <h6><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-2.png" alt="Cure Poxy" title="Cure Poxy" class="invert"></h6>
                                <a class="close-compare" href="javascript:void(0)">X</a>
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="compare.php">
                                    <span>Request for Sample</span>
                                </a>
                            </div>
                            <div class="column">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/product-1.jpg" alt="Cure Poxy" title="Cure Poxy">
                                </figure>
                                <h6><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-1.png" alt="Cure Poxy" title="Cure Poxy" class="invert"></h6>
                                <a class="close-compare" href="javascript:void(0)">X</a>
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="compare.php">
                                    <span>Request for Sample</span>
                                </a>
                            </div>
                            <div class="column">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/product-3.jpg" alt="Cure Poxy" title="Cure Poxy">
                                </figure>
                                <h6><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-3.png" alt="Cure Poxy" title="Cure Poxy" class="invert"></h6>
                                <a class="close-compare" href="javascript:void(0)">X</a>
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="compare.php">
                                    <span>Request for Sample</span>
                                </a>
                            </div>
                            <div class="column">
                                <figure>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/product-1.jpg" alt="Cure Poxy" title="Cure Poxy">
                                </figure>
                                <h6><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-1.png" alt="Cure Poxy" title="Cure Poxy" class="invert"></h6>
                                <a class="close-compare" href="javascript:void(0)">X</a>
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="compare.php">
                                    <span>Request for Sample</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="compare__body">
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">Type</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                        </div>
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">NVM %</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                        </div>
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">Packaging</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                        </div>
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">Features/Applications</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                        </div>
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">Type</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                            <div class="column">
                                <p class="h8">Phenalkamine</p>
                            </div>
                        </div>
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">NVM %</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                            <div class="column">
                                <p class="h8">Solvent Free</p>
                            </div>
                        </div>
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">Packaging</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                            <div class="column">
                                <p class="h8">30 kg & 200 kg</p>
                            </div>
                        </div>
                        <div class="compare__row">
                            <div class="catgory__list">
                                <p class="h7 fw--sb">Features/Applications</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                            <div class="column">
                                <p class="h8">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance applications such as wet surface adhesion.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>