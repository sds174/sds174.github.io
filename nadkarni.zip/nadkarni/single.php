<?php
get_header();
$Url = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
$Url .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
?>
 <main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash">You may also like</p>
                    <h1 class="h1">Insights</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="insights__details bg--nadkarniWhite pt-2 mb-0">
        <div class="main-container">
            <div class="inner-container flow-rootX2">
                <figure>
                    <img src="https://via.placeholder.com/1920x750/e6e6e6">
                </figure>
                <article class="flow-rootX4">
                    <div class="main__title">
                        <h2 class="h4">Title of the blog</h2>
                    </div>
                    <div class="main__content flow-rootX2 h7">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                        <p> It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
                        <p>Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.</p>
                        <figure>
                            <img src="https://via.placeholder.com/1920x750/e6e6e6">
                        </figure>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                        <p> It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
                        <p>Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.</p>
                    </div>
                    <ul class="blog__social__links">
                        <li><a class="hvr:bg--facebook" href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/facebook.svg" title="Share this blog on Facebook" alt="Share this blog on Facebook"></a></li>
                        <li><a class="hvr:bg--twitter" href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/twitter.svg" title="Share this blog on Twitter" alt="Share this blog on Twitter"></a></li>
                        <li><a class="hvr:bg--linkedin" href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/linkedin.svg" title="Share this blog on Linkedin" alt="Share this blog on Linkedi"></a></li>
                        <li><a class="hvr:bg--whatsappgreen" href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/whatsapp.svg" title="Share this blog on WhatsApp" alt="Share this blog on WhatsApp"></a></li>
                        </ul>
                </article>
            </div>
        </div>
    </section>
</main>
<?php 
    get_footer();
?>  
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>

            
            
            