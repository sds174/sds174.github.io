<?php
get_header();
?> 

<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>