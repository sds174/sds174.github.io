<?php
require_once(dirname(dirname(dirname(dirname(dirname(__FILE__))))) . DIRECTORY_SEPARATOR . 'wp-load.php');

Class SendEmail{

	public function __construct(){}

	public function template($body){
		$header = get_option('email_header');
		$footer = get_option('email_footer');
		$link = get_stylesheet_directory_uri().'/assets/img';
		$header = str_replace('{url}', $link, $header);
		$footer = str_replace('{url}', $link, $footer);
		return `<!DOCTYPE html>
		<html>
		    <head>
		        <title>Mail Template</title>
		        <meta charset="utf-8">
		    </head>
		    <body>
				<!-- HEADER -->
					`.$header.`
				<!-- HEADER -->
				<!-- BODY -->
					`.$body.`
					<!-- BODY -->
				<!-- FOOTER -->
					`.$footer.`
				<!-- FOOTER -->      
		    </body>
		</html>`;

	}
}
