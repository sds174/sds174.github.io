<?php
//Add theme settings page
add_action('admin_menu', 'mbw_theme_settings');

function mbw_theme_settings() {
  add_menu_page( "Theme Settings", "Theme Settings", "manage_options", "theme-panel", "theme_settings_page", null, 99);
}

//Display the form
function theme_settings_page()
{
  include(dirname(__FILE__) . DIRECTORY_SEPARATOR .'settings.php');
}

//All Fields
function display_theme_panel_fields()
{
  register_setting("mbw_theme_section", "site_title");
  register_setting("mbw_theme_section", "think_text");
  register_setting("mbw_theme_section", "office_email");
  register_setting("mbw_theme_section", "phone_number_one");
  register_setting("mbw_theme_section", "phone_number_two");
  register_setting("mbw_theme_section", "whatsapp_no_one");
  register_setting("mbw_theme_section", "whatsapp_no_two");
  register_setting("mbw_theme_section", "tech_support_email");
  register_setting("mbw_theme_section", "tech_support_no_one");
  register_setting("mbw_theme_section", "tech_support_no_two");
  register_setting("mbw_theme_section", "customer_support_email");
  register_setting("mbw_theme_section", "customer_support_number");
  register_setting("mbw_theme_section", "office_address");
  //register_setting("mbw_theme_section", "ph_no");
  register_setting("mbw_theme_section", "footer_content"); 
  register_setting("mbw_theme_section", "site_short_text");
    //register_setting("mbw_theme_section", "email_id");

  // register_setting("mbw_theme_section", "email_header");
  // register_setting("mbw_theme_section", "email_footer");
 
  add_settings_section("mbw_theme_section", "Theme Settings", null, "theme-options");
  add_settings_field("Site Title", "Site Title", "site_title", "theme-options", "mbw_theme_section");
  add_settings_field("Site Think Text", "Site Think Text", "think_text", "theme-options", "mbw_theme_section");
  add_settings_field("Office Email", "Office Email", "office_email", "theme-options", "mbw_theme_section");
	add_settings_field("Phone Number One", "Phone Number One", "phone_number_one", "theme-options", "mbw_theme_section");
  add_settings_field("Phone Number Two", "Phone Number Two", "phone_number_two", "theme-options", "mbw_theme_section");
  add_settings_field("Whatsapp Number One", "Whatsapp Number One", "whatsapp_no_one", "theme-options", "mbw_theme_section");
  add_settings_field("Whatsapp Number Two", "Whatsapp Number Two", "whatsapp_no_two", "theme-options", "mbw_theme_section");
  add_settings_field("Technical Support Email", "Technical Support Email", "tech_support_email", "theme-options", "mbw_theme_section");
  add_settings_field("Technical Support No One", "Technical Support No One", "tech_support_no_one", "theme-options", "mbw_theme_section");
  add_settings_field("Technical Support No Two", "Technical Support No Two", "tech_support_no_two", "theme-options", "mbw_theme_section");
  add_settings_field("Customer Support Email", "Customer Support Email", "customer_support_email", "theme-options", "mbw_theme_section");
  add_settings_field("Customer Support Number", "Customer Support Number", "customer_support_number", "theme-options", "mbw_theme_section");
  add_settings_field("Office Address", "Office Address", "office_address", "theme-options", "mbw_theme_section");
  add_settings_field("Footer Content", "Footer Content", "footer_content", "theme-options", "mbw_theme_section");
  add_settings_field("Site Short Text", "Site Short Text", "site_short_text", "theme-options", "mbw_theme_section");
  //add_settings_field("email_id", "Email ID", "email_id", "theme-options", "mbw_theme_section");

  // add_settings_field("email_header", "Email Template Header", "email_header", "theme-options", "mbw_theme_section");  
  // add_settings_field("email_footer", "Email Template Footer", "email_footer", "theme-options", "mbw_theme_section");
}

add_action("admin_init", "display_theme_panel_fields");

function site_title()
{
?>
  <div class="social-media">
      <input type="text" name="site_title" id="site_title" value="<?php echo get_option('site_title'); ?>" />
  </div>    
  <?php
}
function think_text()
{
?>
  <div class="social-media">
      <input type="text" name="think_text" id="think_text" value="<?php echo get_option('think_text'); ?>" />
  </div>    
  <?php
}
function office_email()
{
?>
  <div class="social-media">
      <input type="text" name="office_email" id="office_email" value="<?php echo get_option('office_email'); ?>" />
  </div>    
  <?php
}
function phone_number_one()
{
?>
  <div class="social-media">
      <input type="text" name="phone_number_one" id="phone_number_one" value="<?php echo get_option('phone_number_one'); ?>" />
  </div>    
  <?php
}
function phone_number_two()
{
?>
  <div class="social-media">
      <input type="text" name="phone_number_two" id="phone_number_two" value="<?php echo get_option('phone_number_two'); ?>" />
  </div>    
  <?php
}
function whatsapp_no_one()
{
?>
  <div class="social-media">
      <input type="text" name="whatsapp_no_one" id="whatsapp_no_one" value="<?php echo get_option('whatsapp_no_one'); ?>" />
  </div>    
  <?php
}
function whatsapp_no_two()
{
?>
  <div class="social-media">
      <input type="text" name="whatsapp_no_two" id="whatsapp_no_two" value="<?php echo get_option('whatsapp_no_two'); ?>" />
  </div>    
  <?php
} 
function tech_support_email()
{
?>
  <div class="social-media">
      <input type="text" name="tech_support_email" id="tech_support_email" value="<?php echo get_option('tech_support_email'); ?>" />
  </div>    
  <?php
} 
function tech_support_no_one()
{
?>
  <div class="social-media">
      <input type="text" name="tech_support_no_one" id="tech_support_no_one" value="<?php echo get_option('tech_support_no_one'); ?>" />
  </div>    
  <?php
} 
function tech_support_no_two()
{
?>
  <div class="social-media">
      <input type="text" name="tech_support_no_two" id="tech_support_no_two" value="<?php echo get_option('tech_support_no_two'); ?>" />
  </div>    
  <?php
} 
function customer_support_email()
{
?>
  <div class="social-media">
      <input type="text" name="customer_support_email" id="customer_support_email" value="<?php echo get_option('customer_support_email'); ?>" />
  </div>    
  <?php
} 
function customer_support_number()
{
?>
  <div class="social-media">
      <input type="text" name="customer_support_number" id="customer_support_number" value="<?php echo get_option('customer_support_number'); ?>" />
  </div>    
  <?php
}
/*function ph_no()
{
?>
  <div class="social-media">
      <input type="text" name="ph_no" id="ph_no" value="<?php echo get_option('ph_no'); ?>" />
  </div>    
  <?php
}*/
function email_id()
{
?>
  <div class="social-media">
      <input type="text" name="email_id" id="email_id" value="<?php echo get_option('email_id'); ?>" />
  </div>    
  <?php
}

//Email Template Header Section
function footer_content()
  {
  ?>
    <div class="email-includes-section editorField">
        <?php 
          $footer_content = get_option('footer_content');
          $settings = array(
            'teeny' => true,
            'textarea_rows' => 4,
            'tabindex' => 1
        );
        wp_editor($footer_content, 'footer_content', $settings);
        ?>
    </div>    
  <?php
} 

function office_address()
{
  ?>
    <div class="email-includes-section editorField">
        <?php 
          $office_address = get_option('office_address');
          $settings = array(
            'teeny' => true,
            'textarea_rows' => 4,
            'tabindex' => 1
        );
        wp_editor($office_address, 'office_address', $settings);
        ?>
    </div>    
  <?php
} 

function site_short_text()
{
  ?>
    <div class="email-includes-section editorField">
        <?php 
          $site_short_text = get_option('site_short_text');
          $settings = array(
            'teeny' => true,
            'textarea_rows' => 4,
            'tabindex' => 1
        );
        wp_editor($site_short_text, 'site_short_text', $settings);
        ?>
    </div>    
  <?php
}

//Email Template Header Section
/*function email_header()
  {
  ?>
    <div class="email-includes-section editorField">
        <?php 
          $email_header = get_option('email_header');
          $settings = array(
            'teeny' => true,
            'textarea_rows' => 8,
            'tabindex' => 1
        );
        wp_editor($email_header, 'email_header', $settings);
        ?>
    </div>    
  <?php
}

//Email Template Footer Section
function email_footer()
  {
  ?>
    <div class="email-includes-section editorField">
        <?php 
          $email_footer = get_option('email_footer');
          $settings = array(
            'teeny'         => true,
            'textarea_rows' => 8,
            'tabindex'      => 1
          );
          wp_editor($email_footer, 'email_footer', $settings);
        ?>
    </div>    
  <?php
}*/
