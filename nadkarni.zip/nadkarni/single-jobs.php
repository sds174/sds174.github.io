<?php
	get_header();  
    if (have_posts()) : while (have_posts()) : the_post();
?>
<main class="main mbi-home mb-invert-header marble-career-details">
    <div class="main-wrap" data-scroll-container>
        <section class="header-inner bg--mbBlue m-0 p-0">
           <?php get_template_part('partials/common/inner-header'); ?>
        </section>

        <div class="section scroll-section fl-left w-100" data-scroll-section>
            <?php 
            get_template_part('partials/career-details/banner-section');
            get_template_part('partials/career-details/information-section');
            get_template_part('partials/career-details/similarprofile-section');
            get_template_part('partials/common/rank-companies'); 
            ?>
<?php endwhile;
endif; ?>
<?php get_footer();?>