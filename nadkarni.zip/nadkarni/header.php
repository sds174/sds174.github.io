<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="theme-color" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <title><?php echo is_front_page() ? 'Home | Nadkarni' : wp_title(''); ?></title>
    <!-- <style>
            i.error{
                color: #ffbd8d !important;
            }
        </style> -->
    <?php wp_head() ?>
</head>
<body>
    <div id="main-preloader" class="main-preloader semi-dark-background">
        <div class="main-preloader-inner center">
            <h1 class="preloader-percentage center">
                <span class="preloader-percentage-text">0</span>
                <span class="percentage">%</span>
            </h1>
            <div class="preloader-bar-outer">
                <div class="preloader-bar"></div>
            </div>
        </div>
    </div>

    <?php
    if (is_front_page()) {
    ?>
        <header>
            <div class="nav__menu">
                <svg class="svg-hexa" viewBox="0 0 93.210571 106.37898" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg">
                    <path style="fill:none;fill-rule:evenodd;stroke:white;stroke-width:1.565;stroke-miterlimit:4;stroke-dasharray:none" d="M 91.353769,80.255108 45.540019,105.47562 0.79154018,78.410008 1.8568082,26.12388 47.670555,0.90336575 92.419029,27.968978 Z" />
                </svg>
                <svg class="svg-plus" style="fill:white;fill-rule:evenodd;stroke:none;" viewBox="0 0 100 100">
                    <text x="22" y="56" class="heavy">M</text>
                    <text x="38" y="56" class="heavy">E</text>
                    <text x="50" y="56" class="heavy">N</text>
                    <text x="64" y="56" class="heavy">U</text>
                </svg>
                <svg class="svg-close" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50; fill: white;" xml:space="preserve">
                    <g id="Layer_1">
                        <polygon points="2.707,48.707 25,26.414 47.293,48.707 48.707,47.293 26.414,25 48.707,2.707 47.293,1.293 25,23.586 2.707,1.293 1.293,2.707 23.586,25 1.293,47.293" />
                    </g>
                </svg>

            </div>
            <div class="main-container">
                <div class="inner-container">
                    <div class="header__left">
                        <h1 class="main__logo"><a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" alt="Nadkarni" title="Nadkarni"></a></h1>
                        <article>
                            <?php
                            $site_title = get_option('site_title');
                            $think_text = get_option('think_text');
                            $site_short_text = get_option('site_short_text');
                            ?>
                            <h2 class="h3 c--nadkarniDarkRed fw--m"><?php echo $site_title;?> </h2>
                            <h3 class="h1 c--nadkarniGreen fw--m"><?php echo $think_text;?></h3>
                            <p class="h7 c--nadkarniDarkCream fw--m"><?php echo $site_short_text;?></p>
                            <a class="scroll__down scrollLink" href="#think"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/angle-down.svg"></a>
                        </article>
                    </div>
                    <div class="header__right">
                        <video poster="" playsinline loop muted autoplay>
                            <source src="https://video.wixstatic.com/video/8045a8_e5b6b1480c7f4dc6bfdbb500ed3129cb/360p/mp4/file.mp4" type="video/mp4" />
                        </video>
                        <!-- Menu Style -->
                        <div class="navigation__full">
                            <nav aria-label="main-navigation">
                                <?php
                                $nav_menu = array(
                                    'container'       => 'ul',
                                    'theme_location'  => 'header_menu',
                                    'menu_class'     => '',
                                    'walker'          => new Custom_Walker_Nav_Menu() // Use the custom walker here
                                );
                                wp_nav_menu($nav_menu); ?>
                            </nav>
                            <div class="split__block">
                                <div class="address__block">
                                    <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-9.png" alt="Office Address" title="Office Address"></figure>
                                    <article class="flow-rootx">
                                        <div>
                                            <p class="h8 fw--m">Office</p>
                                            <p class="h9  c--nadkarniDarkRed">Address:</p>
                                            <?php
                                            $office_address = get_option('office_address');
                                            ?>
                                            <p class="h9 c--nadkarniDarkCream"><?php echo $office_address; ?></p>
                                        </div>
                                        <div>
                                            <?php
                                            $office_email = get_option('office_email');
                                            $phone_number_one = get_option('phone_number_one');
                                            $phone_number_two = get_option('phone_number_two');
                                            ?>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a
                                                    href="mailto:<?php echo $office_email; ?>"><?php echo $office_email; ?></a></p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span
                                                    class="c--nadkarniDarkCream"><a href="tel:<?php echo $phone_number_one; ?>​">+91 <?php echo $phone_number_one; ?>​</a> / <a
                                                        href="tel:<?php echo $phone_number_two; ?>"><?php echo $phone_number_two; ?></a></span></p>
                                        </div>
                                    </article>
                                    <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-10.png" alt="WhatsApp" title="WhatsApp"></figure>
                                    <?php
                                    $whatsapp_no_one = get_option('whatsapp_no_one');
                                    $whatsapp_no_two = get_option('whatsapp_no_two');
                                    $whatsapp_no_one = preg_replace('/\s+/', '', trim($whatsapp_no_one));
                                    $whatsapp_no_two = preg_replace('/\s+/', '', trim($whatsapp_no_two));
                                    ?>
                                    <article>
                                        <p class="h8 fw--m">WhatsApp:</p>
                                        <span class="h9 c--nadkarniDarkCream"><a href="tel:<?php echo esc_attr($whatsapp_no_one); ?>">+91 <?php echo $whatsapp_no_one; ?>​</a> / <a href="tel:<?php echo esc_attr($whatsapp_no_two); ?>​"><?php echo esc_html($whatsapp_no_two); ?>​</a></span>

                                    </article>
                                </div>
                                <div class="technical__block flow-rootX2">
                                    <div>
                                        <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-12.png" alt="Technical Support" title="Technical Support">
                                        </figure>
                                        <?php
                                        $tech_support_email = get_option('tech_support_email');
                                        $tech_support_no_one = get_option('tech_support_no_one');
                                        $tech_support_no_two = get_option('tech_support_no_two');
                                        ?>
                                        <article>
                                            <p class="h8 fw--m">Technical Support:</p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a
                                                    href="mailto:<?php echo $tech_support_email; ?>"><?php echo $tech_support_email; ?></a></p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span
                                                    class="c--nadkarniDarkCream"><a href="tel:<?php echo $tech_support_no_one; ?>​">+91 <?php echo $tech_support_no_one; ?>​</a> / <a
                                                        href="tel:<?php echo $tech_support_no_two; ?>"><?php echo $tech_support_no_two; ?></a></span></p>
                                        </article>
                                    </div>
                                    <div>
                                        <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-18.png" alt="Customer Support" title="Customer Support"></figure>
                                        <?php
                                        $customer_support_email = get_option('customer_support_email');
                                        $customer_support_number = get_option('customer_support_number');
                                        ?>
                                        <article>
                                            <p class="h8 fw--m">Customer Support:</p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a
                                                    href="mailto:<?php echo $customer_support_email; ?>"><?php echo $customer_support_email; ?></a></p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span
                                                    class="c--nadkarniDarkCream"><a href="tel:<?php echo $customer_support_number; ?>">+91 <?php echo $customer_support_number; ?></a></span></p>
                                        </article>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    <?php } else { ?>
        <header class="inner__header__nadkarni">
            <div class="nav__menu">
                <svg class="svg-hexa" viewBox="0 0 93.210571 106.37898" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg">
                    <path style="fill:none;fill-rule:evenodd;stroke:#009444;stroke-width:1.565;stroke-miterlimit:4;stroke-dasharray:none" d="M 91.353769,80.255108 45.540019,105.47562 0.79154018,78.410008 1.8568082,26.12388 47.670555,0.90336575 92.419029,27.968978 Z" />
                </svg>
                <svg class="svg-plus" style="fill:#009444;fill-rule:evenodd;stroke:none;" viewBox="0 0 100 100">
                    <text x="22" y="56" class="heavy">M</text>
                    <text x="38" y="56" class="heavy">E</text>
                    <text x="50" y="56" class="heavy">N</text>
                    <text x="64" y="56" class="heavy">U</text>
                </svg>
                <svg class="svg-close" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50; fill: #009444; stroke: #009444;" xml:space="preserve">
                    <g id="Layer_1">
                        <polygon points="2.707,48.707 25,26.414 47.293,48.707 48.707,47.293 26.414,25 48.707,2.707 47.293,1.293 25,23.586 2.707,1.293 1.293,2.707 23.586,25 1.293,47.293" />
                    </g>
                </svg>

            </div>
            <div class="main-container">
                <div class="inner-container">
                    <div class="header__left">
                        <h1 class="main__logo"><a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" alt="Nadkarni" title="Nadkarni"></a></h1>
                    </div>
                    <div class="header__right">

                        <!-- Menu Style -->

                        <div class="navigation__full">
                            <nav aria-label="main-navigation">
                                <?php
                                $nav_menu = array(
                                    'container'       => 'ul',
                                    'theme_location'  => 'header_menu',
                                    'menu_class'     => '',
                                    'walker'          => new Custom_Walker_Nav_Menu() // Use the custom walker here
                                );
                                wp_nav_menu($nav_menu); ?>
                            </nav>
                            <div class="split__block">
                                <div class="address__block">
                                    <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-9.png" alt="Office Address" title="Office Address"></figure>
                                    <article class="flow-rootx">
                                        <?php
                                        $office_address = get_option('office_address');
                                        ?>
                                        <div>
                                            <p class="h8 fw--m">Office</p>
                                            <p class="h9  c--nadkarniDarkRed">Address:</p>
                                            <p class="h9 c--nadkarniDarkCream"><?php echo $office_address; ?></p>
                                        </div>
                                        <div>
                                            <?php
                                            $office_email = get_option('office_email');
                                            $phone_number_one = get_option('phone_number_one');
                                            $phone_number_two = get_option('phone_number_two');
                                            ?>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a
                                                    href="mailto:<?php echo $office_email; ?>"><?php echo $office_email; ?></a></p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span
                                                    class="c--nadkarniDarkCream"><a href="tel:<?php echo $tech_support_no_one; ?>​">+91 <?php echo $tech_support_no_one; ?>​</a> / <a
                                                        href="tel:<?php echo $tech_support_no_two; ?>"><?php echo $tech_support_no_two; ?></a></span></p>
                                        </div>
                                    </article>
                                    <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-10.png" alt="WhatsApp" title="WhatsApp"></figure>
                                    <?php
                                    $whatsapp_no_one = get_option('whatsapp_no_one');
                                    $whatsapp_no_two = get_option('whatsapp_no_two');
                                    $whatsapp_no_one = preg_replace('/\s+/', '', trim($whatsapp_no_one));
                                    $whatsapp_no_two = preg_replace('/\s+/', '', trim($whatsapp_no_two));
                                    ?>
                                    <article>
                                        <p class="h8 fw--m">WhatsApp:</p>
                                        <span class="h9 c--nadkarniDarkCream"><a href="tel:<?php echo esc_attr($whatsapp_no_one); ?>">+91 <?php echo esc_html($whatsapp_no_one); ?>​</a> / <a
                                                href="tel:<?php echo esc_attr($whatsapp_no_two); ?>​"><?php echo esc_html($whatsapp_no_two); ?>​</a></span>
                                    </article>
                                </div>
                                <div class="technical__block flow-rootX2">
                                    <div>
                                        <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-12.png" alt="Technical Support" title="Technical Support">
                                        </figure>
                                        <?php
                                        $tech_support_email = get_option('tech_support_email');
                                        $tech_support_no_one = get_option('tech_support_no_one');
                                        $tech_support_no_two = get_option('tech_support_no_two');
                                        ?>
                                        <article>
                                            <p class="h8 fw--m">Technical Support:</p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a
                                                    href="mailto:<?php echo $tech_support_email; ?>"><?php echo $tech_support_email; ?></a></p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span
                                                    class="c--nadkarniDarkCream"><a href="tel:<?php echo esc_attr($tech_support_no_one); ?>​">+91 <?php echo esc_html($tech_support_no_one); ?>​</a> / <a
                                                        href="tel:<?php echo esc_attr($tech_support_no_two); ?>"><?php echo esc_html($tech_support_no_two); ?></a></span></p>

                                        </article>
                                    </div>
                                    <div>
                                        <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-18.png" alt="Customer Support" title="Customer Support"></figure>
                                        <?php
                                        $customer_support_email = get_option('customer_support_email');
                                        $customer_support_number = get_option('customer_support_number');
                                        ?>
                                        <article>
                                            <p class="h8 fw--m">Customer Support:</p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a
                                                    href="mailto:<?php echo $customer_support_email; ?>"><?php echo $customer_support_email; ?></a></p>
                                            <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span
                                                    class="c--nadkarniDarkCream"><a href="tel:<?php echo esc_attr($customer_support_number); ?>">+91 <?php echo esc_html($customer_support_number); ?></a></span></p>
                                        </article>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    <?php } ?>