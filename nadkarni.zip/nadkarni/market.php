<?php
/*
* Template Name: Market Page
*/
get_header();
?>
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash"><?php echo get_field('inner_banner_heading'); ?></p>
                    <h1 class="h1XL c--nadkarniDarkRed text-uppercase fw--l"><?php echo get_the_title(); ?></h1>
                </div>
            </div>
        </div>
    </section>
    <section class="nakdari__markets bg--nadkarniWhite pt-2 mb-0">
        <div class="main-container">
            <div class="inner-container flow-rootX6">
                <article class="flow-rootX4">
                    <div class="main__title ">
                        <h2 class="h3 c--nadkarniGreen"><?php echo get_field('global_presence_section_heading'); ?></h2>
                    </div>
                    <div class="market__map text-center">
                        <figure>
                            <?php
                            $global_presents_map_image = get_field('global_presents_map_image');
                            printf(
                                '<img src="%s" alt="%s" title="%s" class=""/>',
                                $global_presents_map_image['url'],
                                $global_presents_map_image['alt'],
                                $global_presents_map_image['title']
                            );
                            ?>
                            <figcaption>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                            </figcaption>
                        </figure>
                    </div>

                    <div class="markets__cta">
                        <article>
                            <h3 class="h5"><?php echo get_field('global_distributor_heading'); ?></h3>
                            <?php
                            $global_presence_cta_button_link = get_field('global_presence_cta_button_link');
                            ?>
                            <a class="c2a c2a-arw c2a--inline-block bg--nadkarniGreen fw--b c--nadkarniWhite hvr:bg--nadkarniBlack hvr:c--nadkarniWhite size:minimal radius:expandedX2 uppercase" href="<?php echo esc_url($global_presence_cta_button_link['url']); ?>">
                                <span><?php echo esc_html($global_presence_cta_button_link['title']); ?></span>
                            </a>
                        </article>
                    </div>
                </article>

                <article class="flow-rootX4 industries__accord">
                    <div class="main__title ">
                        <h2 class="h3 c--nadkarniGreen"><?php echo get_field('industries_section_heading'); ?></h2>
                    </div>
                    <div class="accord flow-rootx">
                        <?php
                        $j = 0;
                        if (have_rows('industries_card_content')) {
                            while (have_rows('industries_card_content')) {
                                the_row();
                                $industry_title = get_sub_field('industry_title');
                                $j++;
                                if($j == 1){
                                    $style_class='display: block;';
                                    $active='actv';
                                }
                                else {
                                    $style_class='';
                                    $active='';
                                }
                        ?>
                                <h7 class="accord-btn h4 c--nadkarniDarkRed text-uppercase h5 <?php echo $active;?>"><?php echo $industry_title; ?></h7>
                                <div class="accord-target" style="<?php echo $style_class;?>">
                                    <div class="grid grid--2 gap:1-5rem">
                                        <?php
                                        $k = 0;
                                        if (have_rows('card_inside_content')) {
                                            while (have_rows('card_inside_content')) {
                                                the_row();
                                                $card_inside_heading = get_sub_field('card_inside_heading');
                                                $card_inside_image = get_sub_field('card_inside_image');
                                                $card_inside_short_content = get_sub_field('card_inside_short_content');
                                                $k++;
                                        ?>
                                                <div class="card__5">
                                                    <figure>
                                                        <?php
                                                        printf(
                                                            '<img src="%s" alt="%s" title="%s" class=""/>',
                                                            $card_inside_image['url'],
                                                            $card_inside_image['alt'],
                                                            $card_inside_image['title']
                                                        );
                                                        ?>
                                                        <div class="line top"></div>
                                                        <div class="line bottom"></div>
                                                        <div class="line left"></div>
                                                        <div class="line right"></div>
                                                    </figure>
                                                    <article class="flow-rootx3">
                                                        <p class="h6 fw--m"><?php echo $card_inside_heading; ?></p>
                                                        <ul class="list__3">
                                                            <?php echo $card_inside_short_content; ?>
                                                        </ul>
                                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                                            </svg>
                                                        </a>
                                                    </article>
                                                </div>
                                        <?php }
                                        } ?>
                                
                                    </div>
                                </div>

                        <?php }
                        } ?>
                    </div>
                </article>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>