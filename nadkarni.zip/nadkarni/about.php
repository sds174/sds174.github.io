<?php
/*
* Template Name: About Page
*/
get_header();
?>
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash"><?php echo get_field('inner_banner_heading'); ?></p>
                    <h1 class="h1XL c--nadkarniDarkRed text-uppercase fw--l"><?php echo get_the_title(); ?></h1>
                </div>
            </div>
        </div>
    </section>

    <section class="nadkarni__about bg--nadkarniWhite pt-3 mb-0">
        <div class="main-container">
            <div class="inner-container">
                <div class="about__tabs flow-rootX8">
                    <ul class="tab__head">
                        <li><a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniBlack hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:minimal radius:expandedX2 uppercase actv" href="#general"><?php echo get_field('tab_heading_one'); ?></a></li>
                        <li><a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniBlack hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:minimal radius:expandedX2 uppercase" href="#purpose"><?php echo get_field('tab_heading_two'); ?></a></li>
                        <li><a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniBlack hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:minimal radius:expandedX2 uppercase" href="#team"><?php echo get_field('tab_heading_three'); ?></a></li>
                    </ul>
                    <div class="tab__container">
                        <div class="general tab--content flow-rootX4" id="general">
                            <div class="nadkarni__bonding">
                                <div class="main__title single__column flow-rootX2">
                                    <div>
                                        <h2 class="h4 c--nadkarniDarkRed"><?php echo get_field('general_tab_heading'); ?></h2>
                                        <h3 class="h2 c--nadkarniGreen"><?php echo get_field('general_tab_bold_heading'); ?></h3>
                                    </div>
                                    <p class="h6 c--nadkarniDarkCream"><span class="c--nadkarniGreen"><?php echo get_field('general_tab_shorttext_one'); ?></p>
                                    <p class="h6 c--nadkarniDarkCream"><?php echo get_field('general_tab_shorttext_two'); ?></p>
                                </div>
                                <div class="figure">
                                    <figure>
                                        <?php
                                        $rightside_image_one = get_field('rightside_image_one');
                                        printf(
                                            '<img src="%s" alt="%s" title="%s" class=""/>',
                                            $rightside_image_one['url'],
                                            $rightside_image_one['alt'],
                                            $rightside_image_one['title']
                                        );
                                        ?>
                                        <figcaption class="c--nadkarniDarkCream h7"><?php echo get_field('rightside_image_one_caption'); ?></figcaption>
                                    </figure>
                                    <figure>
                                        <?php
                                        $rightside_image_two = get_field('rightside_image_two');
                                        printf(
                                            '<img src="%s" alt="%s" title="%s" class=""/>',
                                            $rightside_image_two['url'],
                                            $rightside_image_two['alt'],
                                            $rightside_image_two['title']
                                        );
                                        ?>
                                        <figcaption class="c--nadkarniDarkCream h7"><?php echo get_field('rightside_image_two_caption'); ?></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="nadkarni__ethics">
                                <div class="ethics__block">
                                    <div class="block-left flow-rootx">
                                        <p class="h2 text-capitalize c--nadkarniWhite"><?php echo get_field('ethics_section_heading'); ?></p>
                                        <div class="accord">
                                            <?php
                                            $j = 0;
                                            if (have_rows('ethics_accordion_content')) {
                                                while (have_rows('ethics_accordion_content')) {
                                                    the_row();
                                                    $accordion_heading = get_sub_field('accordion_heading');
                                                    $accordion_shorttext = get_sub_field('accordion_shorttext');
                                                    $j++;
                                                    if ($j == 1) {
                                                        $active_class = 'actv';
                                                    } else {
                                                        $active_class = '';
                                                    }
                                            ?>
                                                    <h7 class="accord-btn c--nadkarniWhite h5 <?php echo $active_class; ?>"><?php echo $accordion_heading; ?></h7>
                                                    <?php
                                                    if ($j == 1) {
                                                    ?>
                                                        <p class="accord-target c--nadkarniDarkCream h6" style="display: block;">
                                                            <?php echo $accordion_shorttext; ?>
                                                        </p>
                                                    <?php } else { ?>
                                                        <p class="accord-target c--nadkarniDarkCream h6">
                                                            <?php echo $accordion_shorttext; ?>
                                                        </p>
                                                    <?php } ?>
                                            <?php }
                                            } ?>
                                        </div>
                                    </div>
                                    <div class="block-right">
                                        <figure>
                                            <?php
                                            $ethics_section_right_side_image = get_field('ethics_section_right_side_image');
                                            printf(
                                                '<img src="%s" alt="%s" title="%s" class=""/>',
                                                $ethics_section_right_side_image['url'],
                                                $ethics_section_right_side_image['alt'],
                                                $ethics_section_right_side_image['title']
                                            );
                                            ?>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="purpose tab--content flow-rootX5" id="purpose">
                            <div class="nadkarni__visions">
                                <article class="flow-rootX7">
                                    <div>
                                        <i>
                                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 564.4 482.3" style="enable-background:new 0 0 564.4 482.3;" xml:space="preserve">

                                                <g id="telescope-stand" fill="#009343">
                                                    <path d="M310.7,260.9l104.8,210c2,3.9,0.4,8.7-3.6,10.7c-3.9,2-8.7,0.4-10.7-3.6L296.4,268.2v206.1c0,4.4-3.6,8-8,8
                                                c-4.4,0-8-3.6-8-8V268.2L175.6,477.9c-1.9,4-6.7,5.5-10.7,3.6s-5.6-6.7-3.6-10.7l105-209.8c-2.8-1.9-5.4-4.1-7.6-6.6l9.4-13.9
                                                c2.6,4.4,6.7,7.8,11.5,9.7c4.2,1.6,8.8,2,13.2,1.2c1.7-0.3,3.3-0.8,4.8-1.4c1-0.3,2-0.8,2.9-1.3l-32.4-8.2L310.7,260.9z"></path>
                                                </g>

                                                <g id="telescope" fill="#009343">
                                                    <path d="M163.9,481.5L163.9,481.5z M309.7,260.9c15-9.9,21.4-28.6,15.6-45.6l132.3-76.4l8,13.8c1.1,1.8,2.8,3.2,4.9,3.7
                                                c0.7,0.2,1.4,0.3,2.1,0.3c1.4,0,2.8-0.4,4-1.1l27.7-16c3.8-2.2,5.1-7.1,2.9-10.9L435.3,4c-1.1-1.8-2.8-3.2-4.9-3.7
                                                s-4.2-0.2-6.1,0.8l-27.7,16c-3.8,2.2-5.1,7.1-2.9,10.9l8,13.8l-228.6,132c-3.8,2.2-5.1,7.1-2.9,10.9l4,6.9l-62.4,36
                                                c-3.8,2.2-5.1,7.1-2.9,10.9l4,6.9l-62.4,36.1l0,0c-3.8,2.3-5.1,7.2-2.9,11l16,27.7c1.4,2.5,4.1,4,6.9,4c1.4,0,2.8-0.4,4-1.1
                                                l62.4-36l4,6.9c2.2,3.8,7.1,5.1,10.9,2.9l62.4-36l4,7c1.1,1.8,2.8,3.2,4.9,3.7c0.7,0.2,1.4,0.3,2.1,0.3c1.4,0,2.8-0.4,4-1.1
                                                l28.5-16.4c2.2,2.5,4.8,4.7,7.6,6.6L309.7,260.9z M295.4,268.2L295.4,268.2z M287.4,482.3L287.4,482.3z M279.4,268.2L279.4,268.2z
                                                M411.6,26.9l13.9-8l64,110.8l-13.9,8L411.6,26.9z M275.5,207.1c1.6-0.9,3.4-1.6,5.2-2.2c0.5-0.2,1-0.3,1.6-0.4
                                                c1.3-0.3,2.7-0.5,4-0.5c0.6-0.1,1.1-0.1,1.7-0.1c1.9,0,3.8,0.3,5.7,0.8c6.1,1.6,11.4,5.7,14.5,11.2l0,0c0,0,0,0.1,0.1,0.1
                                                c6.6,11.5,2.7,26.1-8.8,32.7c-0.9,0.5-1.9,1-2.9,1.3c-1.5,0.6-3.1,1.1-4.8,1.4c-4.4,0.8-9,0.4-13.2-1.2c-5-2-9.3-5.6-11.9-10.3
                                                C260.1,228.4,264,213.7,275.5,207.1z M188.1,183.7l221.7-128l40,69.3l-132.4,76.5c-1.5-1.7-3.2-3.3-5-4.7c-0.5-0.4-1.1-0.8-1.6-1.2
                                                c-1.4-1-2.9-1.9-4.4-2.8c-0.6-0.3-1.2-0.7-1.8-0.9c-14.3-6.9-31.4-4.6-43.3,5.9c-0.6,0.5-1.1,1.2-1.7,1.7c-1.2,1.2-2.3,2.4-3.4,3.7
                                                c-0.6,0.7-1.1,1.5-1.6,2.3c-0.9,1.2-1.6,2.5-2.3,3.8c-0.4,0.9-0.9,1.7-1.2,2.6c-0.6,1.3-1.1,2.7-1.5,4.1c-0.3,0.9-0.6,1.9-0.8,2.8
                                                c-0.3,1.5-0.6,2.9-0.7,4.4c-0.1,0.9-0.2,1.8-0.3,2.8c-0.1,1.6,0,3.3,0.1,4.9c0.1,0.8,0,1.6,0.2,2.4c0.3,2.3,0.9,4.6,1.6,6.9
                                                c0,0.1,0.1,0.2,0.1,0.4L228,253L188.1,183.7z M126.7,237.5l55.4-32l24,41.6l-55.4,32L126.7,237.5z M65.4,291.4l55.4-32l8,13.9
                                                l-55.4,32L65.4,291.4z"></path>
                                                    <circle fill="#fff" stroke="#009343" stroke-width="15" stroke-miterlimit="10" cx="287.9" cy="228.8" r="32.1"></circle>
                                                </g>
                                            </svg>
                                        </i>
                                        <div class="flow-rootX3 headGrid">
                                            <div class="headingMV">
                                                <h3 class="h2 text-uppercase fw--t">Our</h3>
                                                <h4 class="h1XL text-uppercase fw--t c--nadkarniGreen"><?php echo get_field('vission_heading'); ?></h4>
                                            </div>
                                            <p class="h6"><?php echo get_field('vission_shorttext'); ?></p>
                                        </div>
                                    </div>

                                    <div>
                                        <i id="rocket">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-16.png" alt="Our Mission" title="Our Mission">
                                        </i>
                                        <div class="flow-rootX3 headGrid">
                                            <div class="headingMV">
                                                <h3 class="h2 text-uppercase fw--t">Our</h3>
                                                <h4 class="h1XL text-uppercase fw--t c--nadkarniGreen"><?php echo get_field('mission_section_heading'); ?></h4>
                                            </div>
                                            <p class="h6"><?php echo get_field('mission_shorttext'); ?></p>
                                        </div>
                                    </div>

                                    <div>
                                        <i id="flag">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-17.png?v=1.1" alt="Goal" title="Goal">
                                        </i>
                                        <div class="headGrid">
                                            <div class="headingMV">
                                                <h4 class="h1XL text-uppercase fw--t c--nadkarniGreen"><?php echo get_field('goal_section_heading'); ?></h4>
                                                <p class="h6" style="line-height: 1.5;"><?php echo get_field('goal_shorttext'); ?></p>
                                            </div>
                                            <ul class="list__2">
                                                <?php echo get_field('goal_short_content'); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="nadkarni__goal">
                                <div>
                                    <h2 class="h4 c--nadkarniDarkRed"><?php echo get_field('purpose_section_bottom_heading'); ?></h2>
                                    <h3 class="h2 c--nadkarniGreen"><?php echo get_field('purpose_section_bottom_bold_heading'); ?></h3>
                                </div>
                                <figure>
                                    <?php
                                    $technology_image = get_field('technology_image');
                                    printf(
                                        '<img src="%s" alt="%s" title="%s" class=""/>',
                                        $technology_image['url'],
                                        $technology_image['alt'],
                                        $technology_image['title']
                                    );
                                    ?>
                                </figure>
                            </div>
                        </div>
                        <div class="team tab--content flow-rootX8" id="team">
                            <div class="nadkarni__leadership">
                                <div class="nadkarni__management">
                                    <?php
                                    $args = array(
                                        'post_type' => 'teams',
                                        'posts_per_page' => -1,
                                        'meta_key' => 'team_top_section_member',
                                        'orderby' => 'meta_value',
                                        'post_status' => 'publish',
                                        'order' => 'DESC',
                                        'meta_query' => array(
                                            array(
                                                'key' => 'team_top_section_member',
                                                'value' => true,
                                                'type' => 'BOOLEAN',
                                            ),
                                        )
                                    );
                                    $k = 0;
                                    $teams = new WP_Query($args);
                                    if ($teams->have_posts()) {
                                        while ($teams->have_posts()) {
                                            $teams->the_post();
                                            $k++;
                                    ?>
                                            <div class="management__lead">
                                                <div class="hex">
                                                    <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                                        <defs>
                                                            <pattern id="img1" patternUnits="userSpaceOnUse" width="100" height="100">
                                                                <?php
                                                                $team_person_image = get_field('team_image');
                                                                printf(
                                                                    '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                                    $team_person_image['url'],
                                                                    $team_person_image['url'],
                                                                    $team_person_image['alt'],
                                                                    $team_person_image['title']
                                                                );
                                                                ?>
                                                            </pattern>
                                                        </defs>
                                                        <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img1)"></polygon>
                                                    </svg>
                                                </div>
                                                <article class="flow-rootX2">
                                                    <p class="h6l fw--t"><?php echo get_field('quoted_text'); ?></p>
                                                    <div class="profile__name">
                                                        <p class="h5"><?php echo get_the_title(); ?></p>
                                                        <p class="h7"><?php echo get_field('designation'); ?></p>
                                                    </div>
                                                </article>
                                            </div>
                                    <?php
                                        }
                                    }
                                    wp_reset_postdata(); ?>
                                    <div class="management__sub">
                                    <?php
                                        $args1 = array(
                                            'post_type' => 'teams',
                                            'posts_per_page' => -1,
                                            'post_status' => 'publish',
                                            'order' => 'DESC',
                                            'meta_query' => array(
                                                'relation' => 'OR', 
                                                array(
                                                    'key' => 'team_top_section_member',
                                                    'compare' => 'NOT EXISTS' 
                                                ),
                                                array(
                                                    'key' => 'team_top_section_member',
                                                    'value' => '0', 
                                                    'compare' => '=',
                                                    'type' => 'NUMERIC' 
                                                )
                                            )
                                        );
   										$teams_member = new WP_Query($args1);
                                        if ($teams_member->have_posts()) {
											while ($teams_member->have_posts()) {
												$teams_member->the_post();
										?>
                                        <div class="flow-rootx text-center">
                                            <div class="hex">
                                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                                    <defs>
                                                        <pattern id="img1" patternUnits="userSpaceOnUse" width="100" height="100">
                                                            <?php
                                                                $team_person_image = get_field('team_image');
                                                                printf(
                                                                    '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                                    $team_person_image['url'],
                                                                    $team_person_image['url'],
                                                                    $team_person_image['alt'],
                                                                    $team_person_image['title']
                                                                );
                                                            ?>
                                                        </pattern>
                                                    </defs>
                                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img1)"></polygon>
                                                </svg>
                                            </div>
                                            <div class="sub__profiles">
                                                <p class="h6l"><?php echo get_the_title();?></p>
                                                <p class="h7"><?php echo get_field('designation'); ?></p>
                                            </div>
                                        </div>
                                        <?php
											}
										}
										wp_reset_postdata(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>