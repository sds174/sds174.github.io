<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

get_header();
?>
<main class="main cookies static-page" id="main" data-barba="container" data-barba-namespace="cookies">
    <?php  
        get_template_part('partials/common/inner-header');  
    ?>
    <div class="main-wrap" data-scroll-container>
        <div class="section-wrap" id="top" data-scroll-section>
            <section class="section alpha-hero alpha-inner-hero">
                <div class="main-container">
                    <div class="inner-container">
                        <div class="hero-article" data-transition-slide-in>
                            <article class="flow-rootX6">
                                <p class="h2 c--alpWhite fw--m"><?php the_title(); ?></p>
                            </article>
                        </div>
                    </div>
                </div>
                <div class="blur blur-3"></div>
            </section>

            <section class="section static-content">
                <div class="main-container">
                    <div class="inner-container">
                        <article class="flow-rootX9">
                            <div class="flow-rootX2">
                                <?php the_content(); ?>
                            </div>
                        </article>
                    </div>
                </div>
            </section>
            
        <?php get_footer(); ?>