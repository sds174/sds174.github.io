<?php
/*
* Template Name: Product Page
*/
get_header();
?> 
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash">Wide-Ranging Products</p>
                    <h1 class="h1XL c--nadkarniDarkRed text-uppercase fw--l">Products</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="product__banner pt-0 pb-2">
        <figure>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/image-19.jpg" alt="Product Banner" title="Product Banner">
        </figure>
    </section>
    <section class="product__list bg--nadkarniWhite pt-0 pb-0 mb-0">
        <div class="main-container">
            <div class="inner-container">
                <div class="product--row">
                    <div class="product__brand flow-rootx">
                        <div class="sticky__brand flow-rootX2">
                            <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-1.png?v=1.1" alt="Solopoxy" title="Solopoxy"></figure>
                            <article class="flow-rootX2">
                                <h2 class="h7">SOLOPOXY is our 
                                flagship technology that offers the performance of two-pack epoxy 
                                coatings in the convenience of a single pack air-drying system.</h2>
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniDarkCream hvr:bg--txt hvr:bg--nadkarniDarkCream hvr:c--nadkarniWhite size:less radius:expandedX2 uppercase" href="product-listing.php">
                                    <span>View All</span>
                                    <span class="material-icons-outlined">east</span>
                                </a>
                            </article>
                        </div>
                    </div>
                    <div class="product__blocks grid grid--3 gap:1rem">
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                    </div>
                </div>

                <div class="product--row">
                    <div class="product__brand flow-rootx">
                        <div class="sticky__brand flow-rootX2">
                            <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-2.png?v=1.1" alt="Curepoxy" title="Curepoxy"></figure>
                            <article class="flow-rootX2">
                                <h2 class="h7">CURE-O-POXY offers Superior Epoxy 
                                Hardeners that crosslink with Epoxy Resins in 
                                a two-pack system to form long lasting 
                                protective coatings.</h2>
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniDarkCream hvr:bg--txt hvr:bg--nadkarniDarkCream hvr:c--nadkarniWhite size:less radius:expandedX2 uppercase" href="product-listing.php">
                                    <span>View All</span>
                                    <span class="material-icons-outlined">east</span>
                                </a>
                            </article>
                        </div>
                    </div>
                    <div class="product__blocks grid grid--3 gap:1rem">
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                    </div>
                </div>

                <div class="product--row">
                    <div class="product__brand flow-rootx">
                        <div class="sticky__brand flow-rootX2">
                            <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-3.png?v=1.1" alt="Neopoxy" title="Neopoxy"></figure>
                            <article class="flow-rootX2">
                                <h2 class="h7">NEOPOXY offers high molecular weight 
                                Cardanol-modified Epoxy Resins and Diluents for two-pack applications. </h2>
                                <a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniDarkCream hvr:bg--txt hvr:bg--nadkarniDarkCream hvr:c--nadkarniWhite size:less radius:expandedX2 uppercase" href="product-listing.php">
                                    <span>View All</span>
                                    <span class="material-icons-outlined">east</span>
                                </a>
                            </article>
                        </div>
                    </div>
                    <div class="product__blocks grid grid--3 gap:1rem">
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                        <div class="card__4">                     
                            <!-- <figure><a href="product-details.php"><img src="./assets/img/placeholder-2.jpg"></a></figure> -->
                            <article class="flow-rootx2 c2a-parent">
                                <p class="h6 c--nadkarniGreen"><a href="product-details.php">Cure Poxy  8040</a></p>
                                <p class="h7">Phenalkamine</p>
                                <p class="h8 product__desc">Low viscosity, solvent-free and 
                                        fumeless Phenalkamine Resin for
                                        high-performance applications  ...</p>
                                <a class="c2a-arw c2a-arw--TR" href="product-details.php">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                    </svg>
                                 </a>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>