<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package WordPress
 */

	get_header();

	if ( have_posts() ) {
?>

<main class="main whoweare inner-header" id="whoweare" data-barba="container" data-barba-namespace="whoweare">
    <?php 
        get_template_part('partials/common/sticky--cursor'); 
    ?>
    
    <div class="main-wrap" data-scroll-container>
        <?php  
            get_template_part('partials/common/inner-header');  
        ?>
        <div class="section" id="top" data-scroll-section>

		<section class="sadekya--support-wrap bg--whitee c--blak sadekya--search">
			<div class="wide-container">
				<div class="inner-container">
					<div class="standline bg--blackk" style="width: 100%;"></div>

						<header class="page-header alignwide">
							<h1 class="page-title">
								<?php
									printf(
										/* translators: %s: Search term. */
										esc_html__( 'Results for "%s"', 'sadekya' ),
										'<span class="page-description search-term">' . esc_html( get_search_query() ) . '</span>'
									);
								?>
							</h1>
						</header><!-- .page-header -->

						<div class="search-result-count default-max-width">
							<?php
								printf(
									esc_html(
										/* translators: %d: The number of search results. */
										_n(
											'We found %d result for your search.',
											'We found %d results for your search.',
											(int) $wp_query->found_posts, 'sadekya'
										)
									),
									(int) $wp_query->found_posts
								);
							?>
						</div><!-- .search-result-count -->
						<div class="flow-rootX2 article--content">
						<?php
							// Start the Loop.
							while ( have_posts() ) {
								the_post();

								/*
								* Include the Post-Format-specific template for the content.
								* If you want to override this in a child theme, then include a file
								* called content-___.php (where ___ is the Post Format name) and that will be used instead.
								*/
								get_template_part( 'partials/common/content-excerpt', get_post_format() );
							} // End the loop.

							// Previous/next page navigation.
							//twenty_twenty_one_the_posts_navigation();

							the_posts_pagination(
								array(
									'prev_text'          => __( 'Previous', 'Sadekya' ),
									'next_text'          => __( 'Next', 'Sadekya' ),
									'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'Sadekya' ) . ' </span>',
								)
							);

							// If no content, include the "No posts found" template.
							} else {
								get_template_part( 'partials/common/content-none' );
							} 
						?>
						</div>
				</div>
    </div>
</section>

<?php
	//get_template_part('partials/common/page-bottom-contact-section');
	get_footer();
?>