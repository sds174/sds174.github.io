<footer class="mt-0 pb-0">
    <div class="footer__up">
        <div class="main-container">
            <div class="inner-container flow-rootX8">
                <div class="nadkarni__newsletter">
                    <article class="flow-rootx">
                        <div class="newsletter-grid">
                            <div>
                                <h7 class="h2 text-uppercase c--nadkarniGreen">NEWSLETTER</h7>
                                <p class="h7 c--nadkarniBlack">Monthly articles on Polymers & Coatings shared on our website.</p>
                            </div>

                            <a class="c2a c2a-arw outline c2a--inline-block outline c--nadkarniDarkBrown fw--b c--nadkarniWhite hvr:bg--nadkarniDarkBrown hvr:c--nadkarniWhite size:expandedx4 radius:expandedX2 uppercase" href="javascript:void(0)" data-modal="#newsletter">
                                <span>Subscribe Now!</span>
                            </a>
                        </div>

                    </article>
                    <div class="footer__logo"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/footer-logo.png"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__down">
        <div class="main-container">
            <div class="inner-container flow-rootX8">
                <div class="nadkarni__footer-links">
                    <div class="split__block">
                        <div class="general-links">
                            <h5>General Links</h5>
                            <?php
                            $nav_menu_footer = array(
                                'container'       => 'ul',
                                'theme_location'  => 'footer_menu',
                                'menu_class'     => 'f--link',
                            );
                            wp_nav_menu($nav_menu_footer); ?>
                        </div>
                        <div class="legal-links">
                            <h5>Legal Links</h5>
                            <?php
                            $nav_menu_footer_one = array(
                                'container'       => 'ul',
                                'theme_location'  => 'footer_menu_one',
                                'menu_class'     => 'f--link',
                            );
                            wp_nav_menu($nav_menu_footer_one); ?>
                        </div>
                    </div>

                    <div class="split__block">
                        <div class="address__block">
                            <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-9.png" alt="Office Address" title="Office Address"></figure>
                            <article class="flow-rootx">
                                <div>
                                    <?php
                                    $office_address = get_option('office_address');
                                    ?>
                                    <p class="h8 fw--m">Office</p>
                                    <p class="h9 c--nadkarniDarkRed">Address:</p>
                                    <p class="h9 c--nadkarniDarkCream"><?php echo $office_address; ?></p>
                                </div>
                                <div>
                                    <?php
                                    $office_email = get_option('office_email');
                                    $phone_number_one = get_option('phone_number_one');
                                    $phone_number_two = get_option('phone_number_two');
                                    ?>
                                    <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:><?php echo $office_email;?>"><?php echo $office_email;?></a></p>
                                    <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:<?php echo $phone_number_one;?>​">+91 <?php echo $phone_number_one;?>​</a> / <a href="tel:<?php echo $phone_number_two;?>"><?php echo $phone_number_two;?></a></span></p>
                                </div>
                            </article>
                            <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-10.png" alt="WhatsApp" title="WhatsApp"></figure>
                            <article>
                                <?php
                                    $whatsapp_no_one = get_option('whatsapp_no_one');
                                    $whatsapp_no_two = get_option('whatsapp_no_two');
                                    $whatsapp_no_one = preg_replace('/\s+/', '', trim($whatsapp_no_one));
                                    $whatsapp_no_two = preg_replace('/\s+/', '', trim($whatsapp_no_two));
                                ?>
                                <p class="h8 fw--m">WhatsApp:</p>
                                <span class="c--nadkarniDarkCream h9"><a href="tel:<?php echo esc_attr($whatsapp_no_one);?>">+91 <?php echo esc_html($whatsapp_no_one);?>​</a> / <a href="tel:<?php echo esc_attr($whatsapp_no_two);?>​"><?php echo esc_html($whatsapp_no_two);?>​</a></span>
                            </article>
                        </div>
                        <div class="technical__block flow-rootX2">
                            <div>
                                <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-12.png" alt="Technical Support" title="Technical Support"></figure>
                                <article>
                                    <?php
                                        $tech_support_email = get_option('tech_support_email');
                                        $tech_support_no_one = get_option('tech_support_no_one');
                                        $tech_support_no_two = get_option('tech_support_no_two');
                                    ?>

                                    <p class="h8 fw--m">Technical Support:</p>
                                    <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:<?php echo $tech_support_email;?>"><?php echo $tech_support_email;?></a></p>
                                    <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:<?php echo $tech_support_no_one;?>​">+91 <?php echo $tech_support_no_one;?>​</a> / <a href="tel:<?php echo $tech_support_no_two;?>"><?php echo $tech_support_no_two;?></a></span></p>

                                </article>
                            </div>
                            <div>
                                <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icon-18.png" alt="Customer Support" title="Customer Support"></figure>
                                <article>
                                    <?php
                                        $customer_support_email = get_option('customer_support_email');
                                        $customer_support_number = get_option('customer_support_number');
                                    ?>
                                    <p class="h8 fw--m">Customer Support:</p>
                                    <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:<?php echo $customer_support_email;?>"><?php echo $customer_support_email;?></a></p>
                                    <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:<?php echo $customer_support_number;?>">+91 <?php echo $customer_support_number;?></a></span></p>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer>
<?php
$copy_right_text = get_option('footer_content');
?>
<div class="footer-copyright">
    <div class="main-container">
        <div class="inner-container">
            <!-- <p class="h8 c--nadkarniWhite">© 2022 Nadkarni Speciality Polymers and Coatings Pvt. Ltd.</p> -->
            <p class="h8 c--nadkarniWhite"><?php echo $copy_right_text; ?></p>
            <div class="sundew__logo">
                <span class="h8 c--nadkarniWhite">Designed by</span>
                <a href="https://sundewsolutions.com" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/sds.png" alt="Sundew Solutions" title="Sundew Solutions"></a>
            </div>
            <a class="arrow-top scrollTop" id="g2t" href="#top"><span class="material-icons-outlined c--whitee">north</span></a>
        </div>
    </div>
</div>


<script src="https://unpkg.co/gsap@3/dist/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.4/ScrollTrigger.min.js"></script>
<script src="https://unpkg.com/gsap@3.11.3/dist/MotionPathPlugin.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/sPreloader.js?v=<?php echo rand() ?>"></script>
<script type="text/javascript">
    jQuery('body').jpreLoader({
        preMainSection: '#main-preloader',
        prePerText: '.preloader-percentage-text',
        preBar: '.preloader-bar',
    });
</script>

<!-- Newsletter Modal -->

<div class="sundew-ui--modal size:sm newsletter--modal" id="newsletter">
    <span class="sundew-ui--modal-bg">

    </span>
    <div class="sundew-ui--modal-scroll">
        <div class="sundew-ui--modal-outer">
            <a href="javascript:" class="sundew-ui--modal-close sds-modal-exit"></a>
            <div class="sundew-ui--modal-inner flow-rootX2">
                <h2 class="h3 c--nadkarniGreen fw--r">Articles, News and <br />Knowledge</h2>
                <p class="h6l fw--l">We value your time and will send only short,
                    valuable topics to your inbox on a monthly basis</p>
                <form class="form-style-4">
                    <div class="form-element">
                        <label for="" class="form-label">Email Address</label>
                        <input type="text" class="form-field">
                    </div>
                    <div class="form-element">
                        <label for="" class="form-label">Name</label>
                        <input type="text" class="form-field">
                    </div>
                    <div class="form-element mt-2">
                        <button class="c2a bg--nadkarniMidCream c--nadkarniDarkBrown radius:expandedX2 size:expandedX w-100p hvr:bg--nadkarniDarkBrown hvr:c--nadkarniWhite" type="submit">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
</body>

</html>