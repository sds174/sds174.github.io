<?php
	get_header();  
    if (have_posts()) : while (have_posts()) : the_post();
?>  
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash">Wide-Ranging Products</p>
                    <h1><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logos/logo-2.png" alt="Curepoxy" title="Curepoxy" class="invert"></h1>
                </div>
            </div>
        </div>
    </section>

    <section class="product__details bg--nadkarniWhite pt-3 mb-0 pb-0">
        <div class="main-container">
            <div class="inner-container">
                <div class="product__show">
                    <figure>
                        <img src="https://via.placeholder.com/500x600/ffffff">
                    </figure>
                </div>
                <div class="product__description flow-rootX2">
                    <div class="grid">
                        <h2 class="h4 c--nadkarniGreen">Cure Poxy 8040</h2>
                    </div>
                    <div class="grid grid-auto-flow-column gap:2rem prd__type">
                        <div class="specs">
                            <p class="h8 c--nadkarniGreen">Type</p>
                            <p class="h6l">Phenalkamine</p>
                        </div>
                        <div class="specs">
                            <p class="h8 c--nadkarniGreen">NVM %</p>
                            <p class="h6l">Solvent Free</p>
                        </div>
                        <div class="specs">
                            <p class="h8 c--nadkarniGreen">Packaging</p>
                            <p class="h6l">30 kg & 200 kg</p>
                        </div>
                    </div>
                    <div class="grid flow-rootx2">
                        <p class="h8 c--nadkarniGreen">Features/Applications - </p>
                        <p class="h7">Low viscosity, solvent-free and fumeless Phenalkamine Resin for high-performance 
                            applications such as wet surface adhesion.</p>
                    </div>
                    <div class="grid flow-rootx2">
                        <p class="h8 c--nadkarniGreen">Resources</p>

                        <div class="details__pdf">
                            <article class="flow-rootx3">
                                <p class="h7">Datasheet</p>
                                <div class="grid grid--3 gap:1rem">
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/pdf.png" alt="Datasheet" title="Datasheet">
                                    </a>
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/pdf.png" alt="Datasheet" title="Datasheet">
                                    </a>
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/pdf.png" alt="Datasheet" title="Datasheet">
                                    </a>
                                </div>
                            </article>
                            <article class="flow-rootx3">
                                <p class="h7">Brochure</p>
                                <div class="grid grid--3 gap:1rem">
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/pdf.png" alt="Datasheet" title="Datasheet">
                                    </a>
                                </div>
                            </article>
                        </div>
                    </div>

                    <div class="grid grid-auto-flow-column gap:1rem button__compare">
                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:less radius:expandedX2 uppercase" href="javascript:void(0)">
                            <span class="material-icons-outlined">sync_alt</span>
                            <span class="text-uppercase">Compare</span>
                        </a>
                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniBlack hvr:bg--txt hvr:bg--nadkarniBlack hvr:c--nadkarniWhite size:less radius:expandedX2 uppercase" href="javascript:void(0)">
                            <span class="material-icons-outlined">edit_road</span>
                            <span class="text-uppercase">Request for Sample</span>
                        </a>
                    </div>
                </div> 
            </div>
        </div>
    </section>

    <section class="nadkarni__similar__products posiR">
        <div class="main-container">
            <div class="inner-container flow-rootX2 overflow-hidden">
                <div class="similar__heading posiR">
                    <h4 class="h4">Similar Products</h4>
                    <div class="swiper-nav-btn custom-arrows posiR">
                        <div class="swiper-button-prev swiper-button-prev-2 swiper-button-white"><span class="material-icons-outlined">west</span></div>
                        <div class="swiper-button-next swiper-button-next-2 swiper-button-white"><span class="material-icons-outlined">east</span></div>
                    </div>
                </div>
                <div class="swiper-container-2" data-scroll>
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="card__4">                     
                                <figure><a href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder-2.jpg"></a></figure>
                                <article class="flow-rootx2 c2a-parent">
                                    <p class="h6 c--nadkarniGreen"><a href="javascript:void(0)">Cure Poxy  8040</a></p>
                                    <p class="h7">Phenalkamine</p>
                                    <p class="h8 product__desc">Low viscosity, solvent-free and 
                                            fumeless Phenalkamine Resin for
                                            high-performance applications  ...</p>
                                    <div class="c2a__grid__container pt-1">
                                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                            <span class="material-icons-outlined">sync_alt</span>
                                            <span class="text-uppercase">Compare</span>
                                        </a>
                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card__4">                     
                                <figure><a href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder-2.jpg"></a></figure>
                                <article class="flow-rootx2 c2a-parent">
                                    <p class="h6 c--nadkarniGreen"><a href="javascript:void(0)">Cure Poxy  8040</a></p>
                                    <p class="h7">Phenalkamine</p>
                                    <p class="h8 product__desc">Low viscosity, solvent-free and 
                                            fumeless Phenalkamine Resin for
                                            high-performance applications  ...</p>
                                    <div class="c2a__grid__container pt-1">
                                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                            <span class="material-icons-outlined">sync_alt</span>
                                            <span class="text-uppercase">Compare</span>
                                        </a>
                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card__4">                     
                                <figure><a href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder-2.jpg"></a></figure>
                                <article class="flow-rootx2 c2a-parent">
                                    <p class="h6 c--nadkarniGreen"><a href="javascript:void(0)">Cure Poxy  8040</a></p>
                                    <p class="h7">Phenalkamine</p>
                                    <p class="h8 product__desc">Low viscosity, solvent-free and 
                                            fumeless Phenalkamine Resin for
                                            high-performance applications  ...</p>
                                    <div class="c2a__grid__container pt-1">
                                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                            <span class="material-icons-outlined">sync_alt</span>
                                            <span class="text-uppercase">Compare</span>
                                        </a>
                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card__4">                     
                                <figure><a href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder-2.jpg"></a></figure>
                                <article class="flow-rootx2 c2a-parent">
                                    <p class="h6 c--nadkarniGreen"><a href="javascript:void(0)">Cure Poxy  8040</a></p>
                                    <p class="h7">Phenalkamine</p>
                                    <p class="h8 product__desc">Low viscosity, solvent-free and 
                                            fumeless Phenalkamine Resin for
                                            high-performance applications  ...</p>
                                    <div class="c2a__grid__container pt-1">
                                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                            <span class="material-icons-outlined">sync_alt</span>
                                            <span class="text-uppercase">Compare</span>
                                        </a>
                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card__4">                     
                                <figure><a href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder-2.jpg"></a></figure>
                                <article class="flow-rootx2 c2a-parent">
                                    <p class="h6 c--nadkarniGreen"><a href="javascript:void(0)">Cure Poxy  8040</a></p>
                                    <p class="h7">Phenalkamine</p>
                                    <p class="h8 product__desc">Low viscosity, solvent-free and 
                                            fumeless Phenalkamine Resin for
                                            high-performance applications  ...</p>
                                    <div class="c2a__grid__container pt-1">
                                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                            <span class="material-icons-outlined">sync_alt</span>
                                            <span class="text-uppercase">Compare</span>
                                        </a>
                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card__4">                     
                                <figure><a href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder-2.jpg"></a></figure>
                                <article class="flow-rootx2 c2a-parent">
                                    <p class="h6 c--nadkarniGreen"><a href="javascript:void(0)">Cure Poxy  8040</a></p>
                                    <p class="h7">Phenalkamine</p>
                                    <p class="h8 product__desc">Low viscosity, solvent-free and 
                                            fumeless Phenalkamine Resin for
                                            high-performance applications  ...</p>
                                    <div class="c2a__grid__container pt-1">
                                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                            <span class="material-icons-outlined">sync_alt</span>
                                            <span class="text-uppercase">Compare</span>
                                        </a>
                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card__4">                     
                                <figure><a href="javascript:void(0)"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder-2.jpg"></a></figure>
                                <article class="flow-rootx2 c2a-parent">
                                    <p class="h6 c--nadkarniGreen"><a href="javascript:void(0)">Cure Poxy  8040</a></p>
                                    <p class="h7">Phenalkamine</p>
                                    <p class="h8 product__desc">Low viscosity, solvent-free and 
                                            fumeless Phenalkamine Resin for
                                            high-performance applications  ...</p>
                                    <div class="c2a__grid__container pt-1">
                                        <a class="c2a c2a-arw c2a--inline outline bg--transparent h9 fw--b c--nadkarniGreen hvr:bg--txt hvr:bg--nadkarniGreen hvr:c--nadkarniWhite size:tiny radius:expandedX2 uppercase" href="javascript:void(0)">
                                            <span class="material-icons-outlined">sync_alt</span>
                                            <span class="text-uppercase">Compare</span>
                                        </a>
                                        <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php endwhile;
endif; ?>
<?php get_footer();?> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>