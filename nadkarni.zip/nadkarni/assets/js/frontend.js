const other = () => {
	jQuery('.scrollTop').click(function(){
		jQuery('html, body').animate({scrollTop:0}, 'slow');
		return false;
	});

	jQuery("a.scrollLink").click(function(event) {
		event.preventDefault();
		jQuery("html, body").animate({
			scrollTop: jQuery(jQuery(this).attr("href")).offset().top
		  }, 500);
	});
}

const tab = () => {
	jQuery(".tab__head a").click(function(e) {
        e.preventDefault(), jQuery(this).addClass("actv"), jQuery(this).parents().siblings().find("a").removeClass("actv");
        var t = jQuery(this).attr("href");
        jQuery(".tab--content").not(t).hide(), jQuery(t).fadeIn()
    })
}

const initSwiper = () => {
    var swiper = new Swiper('.swiper-container', {
		autoplay: {
			delay: 5000,
		},
		speed: 700,
		loop: false,
		spaceBetween: 10,
		allowTouchMove: true,
		slidesPerView: 4,
        navigation: true,
		// If we need pagination
		navigation: {
			nextEl: '.swiper-button-next',
			prevEl: '.swiper-button-prev',
		},
		breakpoints: {
			320: {
				slidesPerView: 1
			},

			475: {
				slidesPerView: 3
			},

			675: {
				slidesPerView: 4
			}
		}
	});

	var swiper2 = new Swiper('.swiper-container-2', {
		autoplay: {
			delay: 5000,
		},
		speed: 700,
		loop: false,
		spaceBetween: 15,
		allowTouchMove: true,
		slidesPerView: 4,
        navigation: true,
		// If we need pagination
		navigation: {
			nextEl: '.swiper-button-next-2',
			prevEl: '.swiper-button-prev-2',
		},
		breakpoints: {
			320: {
				slidesPerView: 1
			},

			475: {
				slidesPerView: 3
			},

			675: {
				slidesPerView: 4
			}
		}
	});
}

const hamMenu = () => {
	jQuery('body').on("click", '.nav__menu', function (e) {
		e.preventDefault();
		var _thisParent = jQuery(this).parents('header');

		jQuery('body').addClass('is-bound');

		_thisParent.find(jQuery('.header__right')).not(jQuery(this).next('.header__right')).toggleClass('menu-active');
		jQuery(this).next('.header__right').slideToggle();

		_thisParent.find(jQuery('.nav__menu')).not(jQuery(this)).removeClass('actv');
		jQuery(this).toggleClass('is-active');
	});
}

const accordMain = () => {
	jQuery('body').on("click", '.accord .accord-btn', function (e) {
		e.preventDefault();
		var _thisParent = jQuery(this).parents('.accord');

		_thisParent.find(jQuery('.accord-target')).not(jQuery(this).next('.accord-target')).slideUp();
		jQuery(this).next('.accord-target').slideToggle();

		_thisParent.find(jQuery('.accord-btn')).not(jQuery(this)).removeClass('actv');
		jQuery(this).toggleClass('actv');
	});
};

const forms = () => {
	let e = document.querySelectorAll(".form-field");
	setTimeout((function () {
		for (let t = 0; t < e.length; t++) e[t].value && (e[t].parentNode.classList.add("has-value"), "TEXTAREA" == e[t].tagName && (e[t].style.cssText = "height: var(--initHeight);", e[t].style.cssText = `height: ${this.scrollHeight}px`))
	}), 100);
	for (let t = 0; t < e.length; t++) "TEXTAREA" == e[t].tagName && e[t].addEventListener("input", (function () {
		this.style.cssText = "height: var(--initHeight);", this.style.cssText = `height: ${this.scrollHeight}px`
	})), e[t].addEventListener("focus", (function () {
		this.parentNode.classList.add("has-value")
	})), e[t].addEventListener("blur", (function () {
		this.value || this.parentNode.classList.remove("has-value")
	}));
	! function (e, t, s) {
		var n = e.querySelectorAll(".inputfile");
		Array.prototype.forEach.call(n, (function (e) {
			var t = e.nextElementSibling,
				s = t.innerHTML;
			e.addEventListener("change", (function (e) {
				var n = "";
				(n = this.files && this.files.length > 1 ? (this.getAttribute("data-multiple-caption") || "").replace("{count}", this.files.length) : e.target.value.split("\\").pop()) ? t.querySelector("span").innerHTML = n : t.innerHTML = s
			})), e.addEventListener("focus", (function () {
				e.classList.add("has-focus")
			})), e.addEventListener("blur", (function () {
				e.classList.remove("has-focus")
			}))
		}))
	}(document, window)
};

window.addEventListener("DOMContentLoaded", () => {
    initSwiper();
	other();
	tab();
	hamMenu();
	accordMain();
	forms();
});
