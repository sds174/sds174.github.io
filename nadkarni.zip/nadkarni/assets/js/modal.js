let vmodalTarget;

function closeModal(){
	jQuery('.sundew-ui--modal').removeClass("showing-modal");
	jQuery("body").removeClass("bound");
	vmodalTarget ? jQuery(vmodalTarget).find('iframe').attr('src', '') : '';
}


jQuery(document).ready(function() {

	// VIDEO MODAL

	
	
	jQuery('body').on('click', (e) => {
		
		vmodalTarget = jQuery(e.target).attr('data-video-modal') 
							? jQuery(e.target).attr('data-video-modal') 
							: jQuery(e.target).closest("[data-video-modal]").attr('data-video-modal');
							
						
		let vimeo_id = jQuery(e.target).attr('data-vimeo-video-id') 
						? jQuery(e.target).attr('data-vimeo-video-id') 
						: jQuery(e.target).closest("[data-vimeo-video-id]").attr('data-vimeo-video-id');


		let yt_id = jQuery(e.target).attr('data-yt-id') 
					? jQuery(e.target).attr('data-yt-id') 
					: jQuery(e.target).closest("[data-yt-id]").attr('data-yt-id');
					
					
		if(vmodalTarget && vimeo_id){
			jQuery("body").addClass("bound");
			jQuery(vmodalTarget).addClass("showing-modal");

			let vimeo_src = 'https://player.vimeo.com/video/' + vimeo_id + "?loop=1&title=0&byline=0&portrait=0";
			jQuery(vmodalTarget).find('iframe').attr('src', vimeo_src);
		}
		else if(vmodalTarget && yt_id){
			jQuery("body").addClass("bound");
			jQuery(vmodalTarget).addClass("showing-modal");


			let yt_src = 'https://www.youtube.com/embed/' + yt_id ;
			jQuery(vmodalTarget).find('iframe').attr('src', yt_src);
		}

		
	});

	
	jQuery('body').on('click', '.sundew-ui--modal-bg', function(){
		closeModal()
	}); 

    jQuery('body').on('click', '.sds-modal-exit', function(){
		closeModal()
	});

	jQuery('body').keyup(function(e) {
		// ESC key maps to keycode `27`
		if (e.keyCode == 27) {
		  // call the close and reset function
		  closeModal();
		}
	});




	/*----------------------------------------------------------------------------*/



	// SDS UI MODAL
	jQuery('body').on('click', (e) => {
		let modalTarget = jQuery(e.target).attr('data-modal') 
							? jQuery(e.target).attr('data-modal') 
							: jQuery(e.target).closest("[data-modal]").attr('data-modal');
		if(modalTarget){
			jQuery('body').find('.sds-ui--modal.showing-modal').removeClass('showing-modal');
			jQuery('body').find(modalTarget).addClass('showing-modal');
			jQuery('body').addClass('bound');
		}
	});


	jQuery('body').on('click', (e) => {
		if(jQuery(e.target).is('.sds-ui--modal-bg')){
			jQuery(e.target).closest('.sds-ui--modal').removeClass('showing-modal');
		}
		else if(jQuery(e.target).is('.sds-ui--modal')){
			jQuery(e.target).removeClass('showing-modal');
		}
	});

});