<?php
/*
* Template Name: Home Page
*/
get_header();
?>
<main class="nadkarni__html">
    <section class="nadkarni__renewable pb-0" id="think">
        <div class="main-container">
            <div class="inner-container flow-rootX2">
                <div class="main__title single__column">
                    <p class="h2 c--nadkarniGreen fw--l"><?php echo get_field('petrochemical_section_heading'); ?></p>
                </div>
                <div class="grid grid--3 gap:1-5rem">
                    <?php
                    if (have_rows('petrochemical_card_content')) {
                        while (have_rows('petrochemical_card_content')) {
                            the_row();
                            $card_heading = get_sub_field('card_heading');
                            $card_short_content = get_sub_field('card_short_content');
                            $link = get_sub_field('card_button_link');
                            $card_image = get_sub_field('card_image');
                    ?>
                            <div class="card__2 flow-rootX2">
                                <figure>
                                    <?php
                                    printf(
                                        '<img src="%s" alt="%s" title="%s" class=""/>',
                                        $card_image['url'],
                                        $card_image['alt'],
                                        $card_image['title']
                                    );
                                    ?>
                                </figure>
                                <article class="flow-rootx">
                                    <p class="h5 c--nadkarniDarkRed fw--m"><?php echo $card_heading; ?></p>
                                    <ul class="list__1 mt-0">
                                        <?php echo $card_short_content; ?>
                                    </ul>
                                    <a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniBlack hvr:bg--txt hvr:bg--nadkarniDarkCream hvr:c--nadkarniWhite size:less radius:expandedX2 uppercase" href="<?php echo esc_url($link['url']); ?>">
                                        <span><?php echo esc_html($link['title']); ?></span>
                                        <span class="material-icons-outlined">east</span>
                                    </a>
                                </article>
                            </div>
                    <?php }
                    } ?>
                </div>
            </div>
        </div>
    </section>
    <section class="nadkarni__best">
        <div class="float__image">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/float-design2.png" id="shape-scroll">
        </div>

        <div class="main-container">
            <div class="inner-container">
                <div class="main__title place__end">
                    <article class="flow-rootx pb-2">
                        <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash"><?php echo get_field('what_we_do_heading'); ?></p>
                        <p class="h2 c--nadkarniGreen fw--l"><?php echo get_field('product_heading'); ?></p>
                        <p class="h5 c--nadkarniDarkRed fw--r"><?php echo get_field('product_short_text'); ?></p>
                    </article>
                    <figure>
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/lion.png" alt="What we do best" title="What we do best" id="lion-scroll">
                    </figure>
                </div>

                <div class="best__products">
                    <div class="grid grid--3 gap:1-5rem">
                        <?php
                        $terms = get_terms(array(
                            'taxonomy' => 'goods_type',
                            'hide_empty' => false, // Show terms even if they don't have posts
                        ));
                        foreach ($terms as $term) {
                            $image_id = get_term_meta($term->term_id, 'product_title_sticker', true);
                            $image_url = wp_get_attachment_image_url($image_id, 'full');
                            $image_id_logo = get_term_meta($term->term_id, 'product_logo_image', true);
                            $image_url_logo = wp_get_attachment_image_url($image_id_logo, 'full');

                        ?>
                            <div class="card__1">
                                <a href="product-listing.php">
                                    <figure>
                                        <img src="<?php echo $image_url_logo; ?>" alt="Solopoxy" title="Solopoxy">
                                    </figure>
                                    <article>
                                        <h6><img src="<?php echo $image_url; ?>" alt="Solopoxy" title="Solopoxy"></h6>
                                    </article>
                                </a>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="nadkarni__markets pb-0">
        <div class="main-container">
            <div class="inner-container flow-rootX4">
                <div class="main__title">
                    <h7 class="h2 c--nadkarniGreen fw--l"><?php echo get_field('markets_section_heading'); ?></h7>
                    <?php
                    $market_cta_link = get_field('market_cta_button_link');
                    ?>
                    <a class="c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniBlack hvr:bg--txt hvr:bg--nadkarniDarkCream hvr:c--nadkarniWhite size:minimal radius:expandedX2 uppercase" href="<?php echo esc_url($market_cta_link['url']); ?>">
                        <span><?php echo esc_html($market_cta_link['title']); ?></span>
                        <span class="material-icons-outlined">east</span>
                    </a>
                </div>

                <div class="best__products">
                    <div class="grid grid--4 gap:1-5rem">
                        <?php
                        if (have_rows('market_card_content')) {
                            while (have_rows('market_card_content')) {
                                the_row();
                                $market_card_inside_image = get_sub_field('market_card_inside_image');
                                $market_card_heading = get_sub_field('market_card_heading');
                                $market_card_link = get_sub_field('market_card_link');
                        ?>
                                <div class="card__1">
                                    <a href="<?php echo $market_card_link; ?>">
                                        <figure>
                                            <?php
                                            printf(
                                                '<img src="%s" alt="%s" title="%s" class=""/>',
                                                $market_card_inside_image['url'],
                                                $market_card_inside_image['alt'],
                                                $market_card_inside_image['title']
                                            );
                                            ?>
                                        </figure>
                                        <article>
                                            <h6 class="c--nadkarniWhite h6"><?php echo $market_card_heading; ?></h6>
                                        </article>
                                    </a>
                                </div>
                        <?php }
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="nadkarni__technology bg--nadkarniCream mb-0">
        <div class="main-container">
            <div class="inner-container flow-rootX8">
                <div class="main__title single__column">
                    <p class="h1XL c--nadkarniGreen fw--l"><?php echo get_field('core_principles_heading'); ?></p>
                </div>

                <div class="grid grid--6 gap:2rem">
                    <?php
                    if (have_rows('core_principles_card_content')) {
                        while (have_rows('core_principles_card_content')) {
                            the_row();
                            $principles_card_link = get_sub_field('principles_card_link');
                            $principles_card_logo = get_sub_field('principles_card_logo');
                            $principles_card_hover_logo = get_sub_field('principles_card_hover_logo');
                            $principles_card_heading = get_sub_field('principles_card_heading');
                    ?>
                            <div class="tech__box">
                                <a href="<?php echo $principles_card_link; ?>" class="flow-rootX2">
                                    <figure>
                                        <svg class="svg-hexa" viewBox="0 0 93.210571 106.37898" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg">
                                            <path style="fill:none;fill-rule:evenodd;stroke:#836947;stroke-width:2;stroke-miterlimit:4;stroke-dasharray:none" d="M 91.353769,80.255108 45.540019,105.47562 0.79154018,78.410008 1.8568082,26.12388 47.670555,0.90336575 92.419029,27.968978 Z" />
                                        </svg>
                                        <figcaption>
                                            <?php
                                            printf(
                                                '<img src="%s" alt="%s" title="%s" class=""/>',
                                                $principles_card_logo['url'],
                                                $principles_card_logo['alt'],
                                                $principles_card_logo['title']
                                            );
                                            ?>
                                            <?php
                                            printf(
                                                '<img src="%s" alt="%s" title="%s" class=""/>',
                                                $principles_card_hover_logo['url'],
                                                $principles_card_hover_logo['alt'],
                                                $principles_card_hover_logo['title']
                                            );
                                            ?>
                                        </figcaption>
                                        <figcaption>
                                            <div class="dots">
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                            </div>
                                        </figcaption>
                                    </figure>
                                    <article>
                                        <p class="h8 fw--m c--nadkarniDarkRed"><?php echo $principles_card_heading; ?></p>
                                    </article>
                                </a>
                            </div>
                    <?php }
                    } ?>

                </div>

            </div>
        </div>
    </section>
    <section class="nadkarni__legacy pb-0">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title">
                    <h7 class="h1 c--nadkarniGreen fw--l"><?php echo get_field('legacy_section_heading'); ?></h7>
                </div>
                <div class="legacy__grid">
                    <div class="legacy__hex">
                        <div class="hex__row uneven">
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_one = get_field('pattern_image_one');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_one['url'],
                                                $pattern_image_one['url'],
                                                $pattern_image_one['alt'],
                                                $pattern_image_one['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img)" />
                                </svg>
                            </div>
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img2" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_two = get_field('pattern_image_two');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_two['url'],
                                                $pattern_image_two['url'],
                                                $pattern_image_two['alt'],
                                                $pattern_image_two['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img2)" />
                                </svg>
                            </div>
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img3" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_three = get_field('pattern_image_three');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_three['url'],
                                                $pattern_image_three['url'],
                                                $pattern_image_three['alt'],
                                                $pattern_image_three['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img3)" />
                                </svg>
                            </div>
                        </div>

                        <div class="hex__row">
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img4" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_four = get_field('pattern_image_four');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_four['url'],
                                                $pattern_image_four['url'],
                                                $pattern_image_four['alt'],
                                                $pattern_image_four['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img4)" />
                                </svg>
                            </div>
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img5" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_five = get_field('pattern_image_five');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_five['url'],
                                                $pattern_image_five['url'],
                                                $pattern_image_five['alt'],
                                                $pattern_image_five['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img5)" />
                                </svg>
                            </div>
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img6" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_six = get_field('pattern_image_six');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_six['url'],
                                                $pattern_image_six['url'],
                                                $pattern_image_six['alt'],
                                                $pattern_image_six['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img6)" />
                                </svg>
                            </div>
                        </div>

                        <div class="hex__row uneven2">
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img7" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_seven = get_field('pattern_image_seven');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_seven['url'],
                                                $pattern_image_seven['url'],
                                                $pattern_image_seven['alt'],
                                                $pattern_image_seven['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img7)" />
                                </svg>
                            </div>
                            <div class="hex">
                                <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                                    <defs>
                                        <pattern id="img8" patternUnits="userSpaceOnUse" width="100" height="100">
                                            <?php
                                            $pattern_image_eight = get_field('pattern_image_eight');
                                            printf(
                                                '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-25" width="150" height="100" />',
                                                $pattern_image_eight['url'],
                                                $pattern_image_eight['url'],
                                                $pattern_image_eight['alt'],
                                                $pattern_image_eight['title']
                                            );
                                            ?>
                                        </pattern>
                                    </defs>
                                    <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img8)" />
                                </svg>
                            </div>

                        </div>
                    </div>
                    <article class="flow-rootX2">
                        <?php
                        $legacy_section_keyword_one = get_field('legacy_section_keyword_one');
                        $remaining_one = substr($legacy_section_keyword_one, 1);
                        $legacy_section_keyword_two = get_field('legacy_section_keyword_two');
                        $remaining_two = substr($legacy_section_keyword_two, 1);
                        $legacy_section_keyword_three = get_field('legacy_section_keyword_three');
                        $remaining_three = substr($legacy_section_keyword_three, 1);
                        ?>
                        <div class="fw--r">
                            <p class="h1"><span class="c--nadkarniGreen"><?php echo $legacy_section_keyword_one[0]; ?></span><?php echo $remaining_one ?>,</p>
                            <p class="h1"><span class="c--nadkarniGreen"><?php echo $legacy_section_keyword_two[0]; ?></span><?php echo $remaining_two; ?> &</p>
                            <p class="h1"><span class="c--nadkarniGreen"><?php echo $legacy_section_keyword_three[0]; ?></span><?php echo $remaining_three; ?></p>
                        </div>
                        <div>
                            <p class="h6"><span class="c--nadkarniBlack fw--m"></span>-</span> <span class="c--nadkarniDarkRed fw--m"><?php echo get_field('owner_name'); ?></span></p>
                            <p class="h5 text-uppercase"><?php echo get_field('legacy_mantra'); ?></p>
                            <?php
                            $legacy_cta_button_link = get_field('legacy_cta_button_link');
                            ?>
                            <a class="mt-1 c2a c2a-arw c2a--inline outline bg--transparent fw--b c--nadkarniBlack hvr:bg--txt hvr:bg--nadkarniDarkRed hvr:c--nadkarniWhite size:minimal radius:expandedX2 uppercase" href="<?php echo esc_url($legacy_cta_button_link['url']); ?>">
                                <span><?php echo esc_html($legacy_cta_button_link['title']); ?></span>
                                <span class="material-icons-outlined">east</span>
                            </a>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <section class="nadkarni__milestones" id="milestones">
        <div class="main-container">
            <div class="inner-container flow-rootX2">
                <div class="main__title single__column fw--t">
                    <p class="h2 c--nadkarniGreen"><?php echo get_field('milestone_section_heading'); ?></p>
                </div>
                <div class="milestone__graphic">
                    <?php
                    $i = 0;
                    if (have_rows('milestones_animation_content')) {
                        while (have_rows('milestones_animation_content')) {
                            the_row();
                            $milestone_icon = get_sub_field('milestone_icon');
                            $milestone_heading = get_sub_field('milestone_heading');
                            $milestone_shorttext = get_sub_field('milestone_shorttext');
                            $i++;
                            if($i == 1){
                               $class='Green';
                            }
                            else if($i == 2){
                                $class='LightGreen';
                            } 
                            else if($i == 3){
                                $class='Orange';
                            } 
                            else if($i == 4){
                                $class='LightChocolate';
                            } 
                            else if($i == 5){
                                $class='MidChocolate';
                            }
                        ?>
                            <div class="anime anime-<?php echo $i;?>">
                                <figure>
                                        <?php
                                            printf(
                                                '<img src="%s" alt="%s" title="%s" class=""/>',
                                                $milestone_icon['url'],
                                                $milestone_icon['alt'],
                                                $milestone_icon['title']
                                            );
                                        ?>
                                    <span></span>
                                </figure>
                                <article class="flow-rootx3">
                                    <p class="h6l c--nadkarni<?php echo $class;?>"><?php echo $milestone_heading;?></p>
                                    <p class="h8"><?php echo $milestone_shorttext;?></p>
                                </article>
                            </div>
                    <?php }
                    } ?>
                     <div class="route" id="route">
                        <svg role="presentation" xmlns="http://www.w3.org/2000/svg" id="svgRoute" width="1400" height="760" viewBox="0 0 1400 760">
                            <defs>
                                <style>
                                    .cls-1 {
                                        fill: none;
                                        stroke: #000;
                                        stroke-linecap: round;
                                        stroke-width: 5px;
                                        stroke-dasharray: 0.001 15;
                                        fill-rule: evenodd;
                                    }
                                </style>
                            </defs>
                            <path id="plane-path" class="cls-1" d="M155,597S389,482,326,302c0,0-63-115,71-158,0,0,85-33,201,75,0,0,123,146,212,111,0,0,69-41,6-92,0,0-82-39-120,84,0,0-51,194,107,290,0,0,127,79,265-13,0,0,149-114,62-288,0,0-89-135,93-185" />
                            <g id="plane">
                                <image x="-40" y="-70" width="76" height="80" xlink:href="<?php echo get_template_directory_uri(); ?>/assets/img/milestones/rocket.png"></image>
                            </g>
                        </svg>

                    </div>

                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/home-frontend.js?v=<?php echo rand() ?>"></script>