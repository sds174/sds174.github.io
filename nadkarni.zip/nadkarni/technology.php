<?php
/*
* Template Name: Technology Page
*/
get_header();
?>
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash"><?php echo get_field('inner_banner_heading'); ?></p>
                    <h1 class="h1XL c--nadkarniDarkRed text-uppercase fw--l"><?php echo get_the_title(); ?></h1>
                </div>
            </div>
        </div>
    </section>

    <section class="nakdari__technology bg--nadkarniWhite pt-2 mb-0">
        <div class="main-container">
            <div class="inner-container flow-rootX6">
                <article class="flow-rootX4">
                    <div class="main__title ">
                        <h2 class="h3 c--nadkarniGreen"><?php echo get_field('sustainability_heading'); ?></h2>
                    </div>
                    <div class="main__content flow-rootX2 h7">
                        <p><?php echo get_field('sustainability_section_short_contnt'); ?></p>
                    </div>
                </article>
                <article class="left-right-grid-1">
                    <figure>
                        <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
                            <defs>
                                <pattern id="img" patternUnits="userSpaceOnUse" width="100" height="100">
                                    <?php
                                    $sustainability_left_section_image = get_field('sustainability_left_section_image');
                                    printf(
                                        '<image xlink:href="%s" src="%s" alt="%s" title="%s" x="-32" width="165" y="-10" height="120" />',
                                        $sustainability_left_section_image['url'],
                                        $sustainability_left_section_image['url'],
                                        $sustainability_left_section_image['alt'],
                                        $sustainability_left_section_image['title']
                                    );
                                    ?>
                                </pattern>
                            </defs>
                            <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img)" />
                        </svg>
                    </figure>
                    <div class="flow-rootX2 h7">
                        <p><?php echo get_field('sustainability_short_text_one'); ?></p>
                        <p><?php echo get_field('sustainability_short_text_two'); ?></p>
                        <p class="h10 c--nadkarniVeryLight"><?php echo get_field('sustainability_short_text_three'); ?></p>
                    </div>
                </article>
                <article class="left-right-grid-2">
                    <div class="flow-rootX2 h7">
                        <div class="main__title single__column flow-rootX2">
                            <h2 class="h3 c--nadkarniGreen"><?php echo get_field('nutshell_section_heading'); ?></h2>
                            <h3 class="h5 c--nadkarniDarkRed"><?php echo get_field('cashew_nut-shell_title'); ?></h3>
                        </div>
                        <p><?php echo get_field('cashew_nut-shell_short_text_one'); ?> </p>
                        <p><?php echo get_field('cashew_nut-shell_short_text_two'); ?></p>
                    </div>
                    <figure>
                        <?php
                        $cashew_nut_shell_image = get_field('cashew_nut_shell_image');
                        printf(
                            '<img src="%s" alt="%s" title="%s" class=""/>',
                            $cashew_nut_shell_image['url'],
                            $cashew_nut_shell_image['alt'],
                            $cashew_nut_shell_image['title']
                        );
                        ?>
                    </figure>
                </article>
                <article class="left-right-grid-1">
                    <figure>
                        <?php
                        $cardanol_section_image = get_field('cardanol_section_image');
                        printf(
                            '<img src="%s" alt="%s" title="%s" class=""/>',
                            $cardanol_section_image['url'],
                            $cardanol_section_image['alt'],
                            $cardanol_section_image['title']
                        );
                        ?>
                    </figure>
                    <div class="flow-rootX2 h7">
                        <div class="main__title single__column flow-rootX2">
                            <h3 class="h5 c--nadkarniDarkRed"><?php echo get_field('cardanol_section_title'); ?></h3>
                        </div>
                        <p><?php echo get_field('cardanol_section_short_text_one'); ?></p>
                        <p><?php echo get_field('cardanol_section_short_text_two'); ?></p>
                    </div>
                </article>
                <!-- ************************* -->
                <?php
                $i = 0;
                if (have_rows('future_ready_tech_card_content')) {
                    while (have_rows('future_ready_tech_card_content')) {
                        the_row();
                        $future_ready_tech_heading = get_sub_field('future_ready_tech_heading');
                        $future_ready_tech_image = get_sub_field('future_ready_tech_image');
                        $future_ready_tech_card_title = get_sub_field('future_ready_tech_card_title');
                        $future_ready_tech_card_short_text = get_sub_field('future_ready_tech_card_short_text');
                        $i++;
                ?>
                        <?php
                        if ($i % 2 == 1) {
                        ?>
                            <article class="left-right-grid-1">
                                <?php
                                if ($i == 1) { ?>
                                    <div class="main__title single__column f--span flow-rootX2 mb-2">
                                        <h4 class="h3 c--nadkarniGreen"><?php echo $future_ready_tech_heading; ?></h4>
                                    </div>
                                <?php } ?>
                                <figure class="with-outline-style hover__effect__1">
                                    <?php
                                    printf(
                                        '<img src="%s" alt="%s" title="%s" class=""/>',
                                        $future_ready_tech_image['url'],
                                        $future_ready_tech_image['alt'],
                                        $future_ready_tech_image['title']
                                    );
                                    ?>
                                    <div class="line top"></div>
                                    <div class="line bottom"></div>
                                    <div class="line left"></div>
                                    <div class="line right"></div>
                                </figure>
                                <div class="flow-rootX2 h7">
                                    <div class="main__title single__column flow-rootX2">
                                        <h5 class="h5 c--nadkarniDarkRed"><?php echo $future_ready_tech_card_title; ?></h5>
                                    </div>
                                    <p><?php echo $future_ready_tech_card_short_text; ?> </p>
                                </div>
                            </article>
                        <?php } else if ($i % 2 == 0) { ?>
                            <article class="left-right-grid-2">
                                <div class="flow-rootX2 h7">
                                    <div class="main__title single__column flow-rootX2">
                                        <h3 class="h5 c--nadkarniDarkRed"><?php echo $future_ready_tech_card_title; ?></h3>
                                    </div>
                                    <p><?php echo $future_ready_tech_card_short_text; ?></p>
                                </div>
                                <figure class="with-outline-style hover__effect__1">
                                    <?php
                                    printf(
                                        '<img src="%s" alt="%s" title="%s" class=""/>',
                                        $future_ready_tech_image['url'],
                                        $future_ready_tech_image['alt'],
                                        $future_ready_tech_image['title']
                                    ); 
                                    ?>
                                    <div class="line top"></div>
                                    <div class="line bottom"></div>
                                    <div class="line left"></div>
                                    <div class="line right"></div>
                                </figure>
                            </article>
                        <?php } ?>
                <?php }
                } ?>
                
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>