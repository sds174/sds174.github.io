    <footer class="mt-0 pb-0">
        <div class="footer__up">
            <div class="main-container">
                <div class="inner-container flow-rootX8">
                    <div class="nadkarni__newsletter">
                        <article class="flow-rootx">
                            <div class="newsletter-grid">
                                <div>
                                    <h7 class="h2 text-uppercase c--nadkarniGreen">NEWSLETTER</h7>
                                    <p class="h7 c--nadkarniBlack">Monthly articles on Polymers & Coatings shared on our website.</p>
                                </div>
                                
                                <a class="c2a c2a-arw outline c2a--inline-block outline c--nadkarniDarkBrown fw--b c--nadkarniWhite hvr:bg--nadkarniDarkBrown hvr:c--nadkarniWhite size:expandedx4 radius:expandedX2 uppercase" href="javascript:void(0)" data-modal="#newsletter">
                                    <span>Subscribe Now!</span>
                                </a>
                            </div>
                            
                        </article>
                        <div class="footer__logo"><img src="./assets/img/footer-logo.png"></div>
                    </div>
                </div>  
            </div>
        </div>
        <div class="footer__down">
            <div class="main-container">
                <div class="inner-container flow-rootX8">
                    <div class="nadkarni__footer-links">
                        <div class="split__block">
                            <div class="general-links">
                                <h5>General Links</h5>
                                <ul class="f--link">
                                    <li><a href="products.php">Products</a></li>
                                    <li><a href="technology.php">Technology</a></li>
                                    <li><a href="markets.php">Markets</a></li>
                                    <!-- <li><a href="insight-lsting.php">Insights</a></li> -->
                                    <li><a href="about.php">About Us</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </div>
                            <div class="legal-links">
                                <h5>Legal Links</h5>
                                <ul class="f--link">
                                    <li><a href="javascript:void(0)">Terms & Conditions</a></li>
                                    <li><a href="javascript:void(0)">Privacy Policy</a></li>
                                    <li><a href="javascript:void(0)">Legal Notice</a></li>
                                </ul>
                            </div>
                        </div>
    
                        <div class="split__block">
                            <div class="address__block">
                                <figure><img src="./assets/img/icons/icon-9.png" alt="Office Address" title="Office Address"></figure>
                                <article class="flow-rootx">
                                    <div>
                                        <p class="h8 fw--m">Office</p>
                                        <p class="h9 c--nadkarniDarkRed">Address:</p>
                                        <p class="h9 c--nadkarniDarkCream">204, Monarch Chambers,<br>
                                            Marol Maroshi Road, Marol Naka, <br>
                                            Andheri (E), Mumbai - 59, India</p>
                                    </div>
                                    <div>
                                        <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:nadkarnispc@gmail.com">nadkarnispc@gmail.com</a></p>
                                        <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:2229250091​">+91 2229250091​</a> / <a href="tel:9619608942">9619608942</a></span></p>
                                    </div>
                                </article>
                                <figure><img src="./assets/img/icons/icon-10.png" alt="WhatsApp" title="WhatsApp"></figure>
                                <article>
                                    <p class="h8 fw--m">WhatsApp:</p>
                                    <span class="c--nadkarniDarkCream h9"><a href="tel:919619643952">+91 9619643952​</a> / <a href="tel:919820373895​">9820373895​</a></span>
                                </article>
                            </div>
                            <div class="technical__block flow-rootX2">
                                <div>
                                    <figure><img src="./assets/img/icons/icon-12.png" alt="Technical Support" title="Technical Support"></figure>
                                    <article>
                                        <p class="h8 fw--m">Technical Support:</p>
                                        <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:sales@nadkarnispc.com">sales@nadkarnispc.com</a></p>
                                        <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:7972884515​">+91 7972884515​</a> / <a href="tel:9820373895">9820373895</a></span></p>
                                        
                                    </article>
                                </div>
                                <div>
                                    <figure><img src="./assets/img/icons/icon-18.png" alt="Customer Support" title="Customer Support"></figure>
                                    <article>
                                        <p class="h8 fw--m">Customer Support:</p>
                                        <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:bonding@nadkarnispc.com">bonding@nadkarnispc.com</a></p>
                                        <p class="h9 c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:9820373895">+91 9820373895</a></span></p>
                                    </article>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </footer>

    <div class="footer-copyright">
        <div class="main-container">
            <div class="inner-container">
                <p class="h8 c--nadkarniWhite">© 2022 Nadkarni Speciality Polymers and Coatings Pvt. Ltd.</p>
                <div class="sundew__logo">
                    <span class="h8 c--nadkarniWhite">Designed by</span>
                    <a href="https://sundewsolutions.com" target="_blank"><img src="./assets/img/sds.png" alt="Sundew Solutions" title="Sundew Solutions"></a>
                </div>
                <a class="arrow-top scrollTop" id="g2t" href="#top"><span class="material-icons-outlined c--whitee">north</span></a>
            </div>
        </div>
    </div>
    

    <script src="https://unpkg.co/gsap@3/dist/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.4/ScrollTrigger.min.js"></script>
    <script src="https://unpkg.com/gsap@3.11.3/dist/MotionPathPlugin.min.js"></script>

    <script type="text/javascript" src="assets/js/jquery.js?v=<?php echo rand()?>"></script>
    <script type="text/javascript" src="assets/js/modal.js?v=<?php echo rand()?>"></script>
    <script type="text/javascript" src="assets/js/swiper-bundle.min.js?v=<?php echo rand()?>"></script>
    <script type="text/javascript" src="assets/js/sPreloader.js?v=<?php echo rand()?>"></script>
    <script type="text/javascript">        
       $('body').jpreLoader({
           preMainSection:     '#main-preloader',
           prePerText:         '.preloader-percentage-text',
           preBar:             '.preloader-bar',
       });       
    </script>

    <!-- Newsletter Modal -->

    <div class="sundew-ui--modal size:sm newsletter--modal" id="newsletter">
        <span class="sundew-ui--modal-bg">
            
        </span>
        <div class="sundew-ui--modal-scroll">
            <div class="sundew-ui--modal-outer">
            <a href="javascript:" class="sundew-ui--modal-close sds-modal-exit"></a>
                <div class="sundew-ui--modal-inner flow-rootX2">
                    <h2 class="h3 c--nadkarniGreen fw--r">Articles, News and <br/>Knowledge</h2>
                    <p class="h6l fw--l">We value your time and will send only short, 
                        valuable topics to your inbox on a monthly basis</p>
                    <form class="form-style-4">
                        <div class="form-element">
                            <label for="" class="form-label">Email Address</label>
                            <input type="text" class="form-field">
                        </div>
                        <div class="form-element">
                            <label for="" class="form-label">Name</label>
                            <input type="text" class="form-field">
                        </div>
                        <div class="form-element mt-2">
                            <button class="c2a bg--nadkarniMidCream c--nadkarniDarkBrown radius:expandedX2 size:expandedX w-100p hvr:bg--nadkarniDarkBrown hvr:c--nadkarniWhite" type="submit">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    </body>
</html>