<!-- Website: Divya Kitchen
Start Date:  August 02, 2022-->


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="theme-color" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="format-detection" content="telephone=no">
        <!-- <link rel="shortcut icon" href="assets/img/__fav/favicon.ico"/>
        <link rel="icon" type="image/png" href="assets/img/__fav/favicon-32x32.png" sizes="32x32" />
        <link rel="icon" type="image/png" href="assets/img/__fav/favicon-16x16.png" sizes="16x16" /> -->
        <title>Nadkarni</title>
        <!-- <link rel="stylesheet" href="assets/vendors/swiper@7.0.1/swiper-bundle.min.css">
        <link rel="stylesheet" href="assets/vendors/simple-lightbox.css?v=<?php echo rand()?>"> -->

        <link rel="stylesheet" href="assets/dart-scss/style.css?v=<?php echo rand()?>">
        <link rel="stylesheet" href="assets/dart-scss/swiper-bundle.min.css?v=<?php echo rand()?>">
    </head>

    <body>

    <div id="main-preloader" class="main-preloader semi-dark-background">
        <div class="main-preloader-inner center">
            <h1 class="preloader-percentage center">
                <span class="preloader-percentage-text">0</span>
                <span class="percentage">%</span>
            </h1>
            <div class="preloader-bar-outer">
                <div class="preloader-bar"></div>
            </div>
        </div>
    </div>