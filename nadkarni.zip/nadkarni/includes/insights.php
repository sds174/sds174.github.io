<section class="nadkarni__insights mb-1">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title">
                    <article class="flow-rootx">
                        <p class="h1XXL c--nadkarniBlack fw--l text-uppercase">Insights</p>
                    </article>
                    <a class="c2a-arw c2a-arw--TR" href="insight-listing.php">
                        <span>View All</span>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M0 0h24v24H0V0z" fill="none"></path>
                            <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                        </svg>
                    </a>
                </div>

                <div class="swiper-main">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="card__3 flow-rootX2">
                                    <figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure>
                                    <article class="flow-rootX2">
                                        <div class="tag">
                                            <span class="h9">Blog Category</span>
                                            <date class="h8">June 15. 2022</date>
                                        </div>
                                        <div class="description flow-rootx3">
                                            <p class="h6">Title of the blog</p>
                                            <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                                et dolore magna aliqua. </p>
                                            <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                    <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                    <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </article>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card__3 flow-rootX2">
                                    <figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure>
                                    <article class="flow-rootX2">
                                        <div class="tag">
                                            <span class="h9">Blog Category</span>
                                            <date class="h8">June 15. 2022</date>
                                        </div>
                                        <div class="description flow-rootx3">
                                            <p class="h6">Title of the blog</p>
                                            <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                                et dolore magna aliqua. </p>
                                            <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                    <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                    <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </article>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card__3 flow-rootX2">
                                    <figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure>
                                    <article class="flow-rootX2">
                                        <div class="tag">
                                            <span class="h9">Blog Category</span>
                                            <date class="h8">June 15. 2022</date>
                                        </div>
                                        <div class="description flow-rootx3">
                                            <p class="h6">Title of the blog</p>
                                            <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                                et dolore magna aliqua. </p>
                                            <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                    <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                    <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </article>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card__3 flow-rootX2">
                                    <figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure>
                                    <article class="flow-rootX2">
                                        <div class="tag">
                                            <span class="h9">Blog Category</span>
                                            <date class="h8">June 15. 2022</date>
                                        </div>
                                        <div class="description flow-rootx3">
                                            <p class="h6">Title of the blog</p>
                                            <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                                et dolore magna aliqua. </p>
                                            <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                    <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                    <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </article>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card__3 flow-rootX2">
                                    <figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure>
                                    <article class="flow-rootX2">
                                        <div class="tag">
                                            <span class="h9">Blog Category</span>
                                            <date class="h8">June 15. 2022</date>
                                        </div>
                                        <div class="description flow-rootx3">
                                            <p class="h6">Title of the blog</p>
                                            <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                                et dolore magna aliqua. </p>
                                            <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                    <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                    <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </article>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card__3 flow-rootX2">
                                    <figure><img src="https://via.placeholder.com/450x350/e6e6e6"></figure>
                                    <article class="flow-rootX2">
                                        <div class="tag">
                                            <span class="h9">Blog Category</span>
                                            <date class="h8">June 15. 2022</date>
                                        </div>
                                        <div class="description flow-rootx3">
                                            <p class="h6">Title of the blog</p>
                                            <p class="h8">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore 
                                                et dolore magna aliqua. </p>
                                            <a class="c2a-arw c2a-arw--TR" href="javascript:">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                    <path d="M0 0h24v24H0V0z" fill="none"></path>
                                                    <path d="M9 5v2h6.59L4 18.59 5.41 20 17 8.41V15h2V5H9z"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </article>
                                </div>
                            </div>
                        </div>
                    </div>
    
                    <div class="swiper-nav-btn custom-arrows">
                        <div class="swiper-button-prev swiper-button-white"><img src="./assets/img/icons/arrow.svg"></div>
                        <div class="swiper-button-next swiper-button-white"><img src="./assets/img/icons/arrow.svg"></div>
                    </div>
                </div>

                
            </div>
        </div>
    </section>