<header class="about__nadkarni">
    <div class="nav__menu">
        <svg class="svg-hexa" viewBox="0 0 93.210571 106.37898" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg">
            <path style="fill:none;fill-rule:evenodd;stroke:white;stroke-width:1.565;stroke-miterlimit:4;stroke-dasharray:none" d="M 91.353769,80.255108 45.540019,105.47562 0.79154018,78.410008 1.8568082,26.12388 47.670555,0.90336575 92.419029,27.968978 Z" />
        </svg>
        <svg class="svg-plus" style="fill:white;fill-rule:evenodd;stroke:none;" viewBox="0 0 100 100">
            <text x="22" y="56" class="heavy">M</text>
            <text x="38" y="56" class="heavy">E</text>
            <text x="50" y="56" class="heavy">N</text>
            <text x="64" y="56" class="heavy">U</text>
        </svg>
        <svg class="svg-close" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50; fill: white;" xml:space="preserve">
            <g id="Layer_1">
                <polygon points="2.707,48.707 25,26.414 47.293,48.707 48.707,47.293 26.414,25 48.707,2.707 47.293,1.293 25,23.586 2.707,1.293 1.293,2.707 23.586,25 1.293,47.293"/>
            </g>
        </svg>

    </div>
    <div class="main-container">
        <div class="inner-container">
            <div class="header__left">
                <h1 class="main__logo"><a href="index.php"><img src="./assets/img/logo.png" alt="Nadkarni" title="Nadkarni"></a></h1>
                <article class="main__title single__column">
                    <p class="h8 c--nadkarniBlack fw-r text-uppercase with__dash mb-2">Who we are</p>
                    <h2 class="h4 c--nadkarniDarkRed">Chemistry is in our genes... </h2>
                    <h3 class="h2 c--nadkarniGreen">Bonding is our strength!</h3>
                    <p class="h7 c--nadkarniDarkCream"><span class="c--nadkarniGreen">Nadkarni Speciality Polymers & Coatings (NSPC) Pvt. Ltd.</span> was founded in November 2021 by the Nadkarni family.</p>
                    <p class="h7 c--nadkarniDarkCream">With <span class="c--nadkarniGreen">3 generations</span> in this business, and a team of 
                        technical experts that possess a combined experience of more than <span class="c--nadkarniGreen">100 years in the Polymers and Coatings 
                        Industry,</span> NSPC is driven by passion and purpose.</p>

                </article>
            </div>
            <div class="header__right">
                <figure class="figure">
                    <img src="./assets/img/about-hero.jpg">
                </figure>
                
                <!-- Menu Style -->

                <div class="navigation__full">
                    <nav aria-label="main-navigation">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li class="dropdown-menu"><a href="#">Products</a>
                                <ul class="dropdown">
                                    <li><a href="products.php">Solopoxy</a></li>
                                    <li><a href="products.php">Cure Poxy</a></li>
                                    <li><a href="products.php">Neopoxy</a></li>
                                </ul>
                            </li>
                            <li><a href="technology.php">Technology</a></li>
                            <li><a href="#">Markets</a></li>
                            <!-- <li><a href="insight-listing.php">Insights</a></li> -->
                            <li><a href="about.php">About us</a></li>
                            <li><a href="contact.php">Contact us</a></li>
                        </ul>
                    </nav>
                    <div class="split__block">
                            <div class="address__block">
                                <figure><img src="./assets/img/icons/icon-9.png" alt="Office Address" title="Office Address"></figure>
                                <article class="flow-rootx">
                                    <div>
                                        <p class="h8 fw--m">Office</p>
                                        <p class="h8 fw--m c--nadkarniDarkRed">Address:</p>
                                        <p class="h8 fw--m c--nadkarniDarkCream">204, Monarch Chambers,<br>
                                            Marol Maroshi Road, Marol Naka, <br>
                                            Andheri (E), Mumbai - 59, India</p>
                                    </div>
                                    <div>
                                        <p class="h8 fw--m c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:nadkarnispc@gmail.com">nadkarnispc@gmail.com</a></p>
                                        <p class="h8 fw--m c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:2229250091​">+91 2229250091​</a> / <a href="tel:9619608942">9619608942</a></span></p>
                                    </div>
                                </article>
                                <figure><img src="./assets/img/icons/icon-10.png" alt="WhatsApp" title="WhatsApp"></figure>
                                <article>
                                    <p class="h8 fw--m">WhatsApp:</p>
                                    <span class="c--nadkarniDarkCream"><a href="tel:919619643952">+91 9619643952​</a> / <a href="tel:919820373895​">9820373895​</a></span>
                                </article>
                            </div>
                            <div class="technical__block flow-rootX2">
                                <div>
                                    <figure><img src="./assets/img/icons/icon-12.png" alt="Technical Support" title="Technical Support"></figure>
                                    <article>
                                        <p class="h8 fw--m">Technical Support:</p>
                                        <p class="h8 fw--m c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:sales@nadkarnispc.com">sales@nadkarnispc.com</a></p>
                                        <p class="h8 fw--m c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:7972884515​">+91 7972884515​</a> / <a href="tel:9820373895">9820373895</a></span></p>
                                        
                                    </article>
                                </div>
                                <div>
                                    <figure><img src="./assets/img/icons/icon-18.png" alt="Customer Support" title="Customer Support"></figure>
                                    <article>
                                        <p class="h8 fw--m">Customer Support:</p>
                                        <p class="h8 fw--m c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Email:</span> <a href="mailto:bonding@nadkarnispc.com">bonding@nadkarnispc.com</a></p>
                                        <p class="h8 fw--m c--nadkarniDarkCream"><span class="c--nadkarniDarkRed">Tel:</span> <span class="c--nadkarniDarkCream"><a href="tel:9820373895">+91 9820373895</a></span></p>
                                    </article>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</header>