<?php
define('MBWVERSION', rand());
include_once('settings/theme-settings.php');
include_once('settings/sendEmail.php');
//loading styles and scripts
add_action('wp_enqueue_scripts', 'MBWScripts');
function MBWScripts()
{
	// Enqueue CSS
	 wp_enqueue_style('main-style', get_template_directory_uri() . '/assets/dart-scss/style.css', array(), MBWVERSION);
	 wp_enqueue_style('dart-style', get_template_directory_uri() . '/assets/dart-scss/swiper-bundle.min.css', array(), MBWVERSION);
	// Enqueue JS
	 wp_enqueue_script('jquery', get_template_directory_uri() . '/assets/js/jquery.js', __FILE__, ['jquery'], true );
	 wp_enqueue_script('jquery-validation', get_stylesheet_directory_uri() . '/assets/js/jquery-validator.js', __FILE__, ['jquery'], '1.19.5');
	 wp_enqueue_script('modal', get_template_directory_uri() . '/assets/js/modal.js', __FILE__, ['jquery'], true ); 
	 wp_enqueue_script('swiper-bundle', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', __FILE__, ['jquery'], true ); 
	//  wp_enqueue_script('preloader', get_template_directory_uri() . '/assets/js/sPreloader.js', __FILE__, ['jquery'], true ,MBWVERSION);
	// wp_enqueue_script('frontend', get_template_directory_uri() . '/assets/js/frontend.js', array(), MBWVERSION, true);

	// wp_enqueue_script('swiper-bundle', 'https://cdnjs.cloudflare.com/ajax/libs/Swiper/6.8.4/swiper-bundle.min.js', array(), null, true);
	
	// wp_localize_script('jquery', 'myAjax', array('ajaxurl' => admin_url('admin-ajax.php')));
	// wp_enqueue_script('functions', get_stylesheet_directory_uri() . '/assets/js/functions.js', __FILE__, ['jquery'], true);
}

//Navigation menus 
register_nav_menus([
	'header_menu' => 'Header Menu',
	'footer_menu' => 'Footer Menu',
	'footer_menu_one' => 'Footer Menu One'
]);

class Custom_Walker_Nav_Menu extends Walker_Nav_Menu {
    // Start Level
    function start_lvl( &$output, $depth = 0, $args = null ) {
        $indent = str_repeat("\t", $depth);
        $classes = array('dropdown');
        $class_names = join(' ', apply_filters('nav_menu_submenu_css_class', $classes, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        $output .= "\n$indent<ul$class_names>\n";
    }
}
//SMTP Settings
function wpse8170_phpmailer_init(PHPMailer $phpmailer)
{
	$phpmailer->isMail();
	$phpmailer->Host = 'smtp.sundewlabs.com';
	$phpmailer->Port = 587;
	$phpmailer->Username = 'development@sundewlabs.com';
	$phpmailer->Password = '(0}ZFd!SO@vo';
	$phpmailer->SMTPAuth = true;
	$phpmailer->SMTPSecure = 'tls';
}

add_filter('wp_mail_from_name', 'new_mail_from_name');
function new_mail_from_name($old)
{
	return 'Marble Box';
}

//Allow Span tags in editor
function myextensionTinyMCE($init)
{
	// Command separated string of extended elements
	$ext = 'span[id|name|class|style]';

	// Add to extended_valid_elements if it alreay exists
	if (isset($init['extended_valid_elements'])) {
		$init['extended_valid_elements'] .= ',' . $ext;
	} else {
		$init['extended_valid_elements'] = $ext;
	}

	// Super important: return $init!
	return $init;
}
add_filter('tiny_mce_before_init', 'myextensionTinyMCE');

add_theme_support('post-thumbnails');

add_action('init', function () {
    // Register Custom Post Type: Goods
    register_post_type('goods', [
        'label' => __('Goods', 'txtdomain'),
        'public' => true,
        'menu_position' => 6,
        'menu_icon' => 'dashicons-businessman',
        'supports' => ['title', 'editor', 'thumbnail'], // Added 'editor' and 'thumbnail' for more functionality
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'goods'],
        'taxonomies' => ['goods_type'], // Associate taxonomies
        // 'capability_type' => 'post',
        // 'capabilities' => [
        //     'edit_post'           => 'edit_goods',
        //     'read_post'           => 'read_goods',
        //     'delete_post'         => 'delete_goods',
        //     'edit_posts'          => 'edit_goods',
        //     'edit_others_posts'   => 'edit_others_goods',
        //     'publish_posts'       => 'publish_goods',
        //     'read_private_posts'  => 'read_private_goods',
        // ],
        // 'map_meta_cap' => true, 
        'labels' => [
            'name' => __('Goods', 'txtdomain'),
            'singular_name' => __('Good', 'txtdomain'),
            'add_new_item' => __('Add New Good', 'txtdomain'),
            'new_item' => __('New Good', 'txtdomain'),
            'view_item' => __('View Good', 'txtdomain'),
            'not_found' => __('No Goods found', 'txtdomain'),
            'not_found_in_trash' => __('No Goods found in Trash', 'txtdomain'),
            'all_items' => __('All Goods', 'txtdomain'),
            'insert_into_item' => __('Insert into Good', 'txtdomain'),
        ],
    ]);

    // Register Taxonomy: Goods Type
    register_taxonomy('goods_type', ['goods'], [
        'label' => __('Type', 'txtdomain'),
        'hierarchical' => true,
        'rewrite' => ['slug' => 'goods-type'],
        'show_admin_column' => true,
        'show_in_rest' => true,
        'labels' => [
            'name' => __('Types', 'txtdomain'),
            'singular_name' => __('Type', 'txtdomain'),
            'all_items' => __('All Types', 'txtdomain'),
            'edit_item' => __('Edit Type', 'txtdomain'),
            'view_item' => __('View Type', 'txtdomain'),
            'update_item' => __('Update Type', 'txtdomain'),
            'add_new_item' => __('Add New Type', 'txtdomain'),
            'new_item_name' => __('New Type Name', 'txtdomain'),
            'search_items' => __('Search Types', 'txtdomain'),
            'parent_item' => __('Parent Type', 'txtdomain'),
            'parent_item_colon' => __('Parent Type:', 'txtdomain'),
            'not_found' => __('No Types found', 'txtdomain'),
        ]
    ]); 
	// Register Non-Hierarchical Taxonomy: Goods Tags
	// New Tag Taxonomy add
    register_taxonomy('goods_tag', ['goods'], [
        'label' => __('Tags', 'txtdomain'),
        'hierarchical' => false, // Set to false for non-hierarchical (tag-like) behavior
        'rewrite' => ['slug' => 'goods-tag'],
        'show_admin_column' => true,
        'show_in_rest' => true,
        'labels' => [
            'name' => __('Tags', 'txtdomain'),
            'singular_name' => __('Tag', 'txtdomain'),
            'all_items' => __('All Tags', 'txtdomain'),
            'edit_item' => __('Edit Tag', 'txtdomain'),
            'view_item' => __('View Tag', 'txtdomain'),
            'update_item' => __('Update Tag', 'txtdomain'),
            'add_new_item' => __('Add New Tag', 'txtdomain'),
            'new_item_name' => __('New Tag Name', 'txtdomain'),
            'search_items' => __('Search Tags', 'txtdomain'),
            'popular_items' => __('Popular Tags', 'txtdomain'),
            'not_found' => __('No Tags found', 'txtdomain'),
        ]
    ]);
	// New Tag Taxonomy add
}); 

add_action('init', function () {
	register_post_type('teams', [
		'label' => __('Teams', 'txtdomain'),
		'public' => true,
		'menu_position' => 5,
		'menu_icon' => 'dashicons-admin-users',
		'supports' => ['title'],
		'show_in_rest' => true,
		'rewrite' => ['slug' => 'teams'],
		'taxonomies' => ['teams_type'],
		'labels' => [
			'singular_name' => __('Teams', 'txtdomain'),
			'add_new_item' => __('Add new Member', 'txtdomain'),
			'new_item' => __('New Member', 'txtdomain'),
			'view_item' => __('View Member', 'txtdomain'),
			'not_found' => __('No Member found', 'txtdomain'),
			'not_found_in_trash' => __('No Member found in trash', 'txtdomain'),
			'all_items' => __('All Members', 'txtdomain'),
			'insert_into_item' => __('Insert into Team', 'txtdomain')
		],
	]);

	register_taxonomy('teams_type', ['teams'], [
		'label' => __('Type', 'txtdomain'),
		'hierarchical' => true,
		'rewrite' => ['slug' => 'teams-type'],
		'show_admin_column' => true,
		'show_in_rest' => true,
		'labels' => [
			'singular_name' => __('Type', 'txtdomain'),
			'all_items' => __('All Types', 'txtdomain'),
			'edit_item' => __('Edit Type', 'txtdomain'),
			'view_item' => __('View Type', 'txtdomain'),
			'update_item' => __('Update Type', 'txtdomain'),
			'add_new_item' => __('Add New Type', 'txtdomain'),
			'new_item_name' => __('New Type Name', 'txtdomain'),
			'search_items' => __('Search Type', 'txtdomain'),
			'parent_item' => __('Parent Type', 'txtdomain'),
			'parent_item_colon' => __('Parent Type:', 'txtdomain'),
			'not_found' => __('No Types found', 'txtdomain'),
		]
	]);
	register_taxonomy_for_object_type('teams_type', 'teams');
});

// To upload photos in format WebP
function wpdocs_custom_mime_types($mimes)
{
	// New allowed mime types.
	$mimes['webp'] = 'image/webp';
	return $mimes;
}

add_filter('upload_mimes', 'wpdocs_custom_mime_types'); 

function enqueue_intl_tel_input() {
    // Enqueue the intl-tel-input CSS
    wp_enqueue_style('intl-tel-input-css', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css');
    
    // Enqueue the intl-tel-input JS
    wp_enqueue_script('intl-tel-input-js', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js', array('jquery'), null, true);
    
	$random_version = rand();
    // Enqueue your custom script
    wp_enqueue_script('custom-form-validation', get_stylesheet_directory_uri() . '/assets/js/custom-form-validation.js', array('intl-tel-input-js'),$random_version, null, true);
}
// add_action('wp_enqueue_scripts', 'enqueue_intl_tel_input');

