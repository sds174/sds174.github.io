<?php
/*
* Template Name: Contact Page
*/
get_header();
?> 
<main class="nadkarni__html inner-m-top">
    <section class="inner__head">
        <div class="main-container">
            <div class="inner-container">
                <div class="main__title place__end">
                    <div>
                        <p class="h8 c--nadkarniBlack fw--r text-uppercase with__dash"><?php echo get_field('inner_banner_heading'); ?></p>
                        <h1 class="h1XL c--nadkarniDarkRed text-uppercase fw--l"><?php echo get_the_title();?></h1>
                    </div>
                    <div>
                        <ul class="general__contact-links">
                            <li><a href="mailto:<?php echo get_field('email_one');?>"><span class="material-icons-outlined">email</span> Mail for Product enquiry</a></li>
                            <li><a href="mailto:<?php echo get_field('email_two');?>"><span class="material-icons-outlined">email</span> Mail for Customer Support</a></li>
                            <li><a href="mailto:<?php echo get_field('email_three');?>"><span class="material-icons-outlined">email</span> General</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="nadkarni__contact bg--nadkarniWhite pt-3 mb-0">
        <div class="main-container">
            <div class="inner-container">
                <div class="form__left flow-rootX2">
                    <h2 class="h4 c--nadkarniGreen"><?php get_field('contact_form_heading');?></h2>
                    <form class="form-style-3">
                        <div class="grid grid--2 gap:1rem">
                            <div class="form-element">
                                <label for="" class="form-label">First Name <span class="c--nadkarniDarkRed">*</span></label>
                                <input type="text" class="form-field">
                            </div>
                            <div class="form-element">
                                <label for="" class="form-label">Last Name <span class="c--nadkarniDarkRed">*</span></label>
                                <input type="text" class="form-field">
                            </div>
                            <div class="form-element">
                                <label for="" class="form-label">Email Address <span class="c--nadkarniDarkRed">*</span></label>
                                <input type="text" class="form-field">
                            </div>
                            <div class="form-element">
                                <label for="" class="form-label">Phone Number <span class="c--nadkarniDarkRed">*</span></label>
                                <input type="text" class="form-field">
                            </div>
                            <div class="form-element">
                                <label for="" class="form-label">Company</label>
                                <input type="text" class="form-field">
                            </div>
                            <div class="form-element form-select">
                                <label for="" class="form-label">Purpose <span class="c--nadkarniDarkRed">*</span></label>
                                <select class="form-field">
                                    <option></option>
                                    <option>Purpose</option>
                                </select>
                            </div>
                        </div>
                        <div class="grid mt-1 flow-rootX2">
                            <div class="form-element">
                                <label for="" class="form-label">Message</label>
                                <textarea class="form-field" rows="6"></textarea>
                            </div>
                            <div class="form-element mb-1">
                                <div class="form-checkbox">
                                    <label>
                                        <input type="checkbox" name="callback_request" value="1">
                                        <span class="checkmark"></span>
                                        <p>I want to request a call back from your end at the given number.</p>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-auto-flow-column captcha__container">
                            <div class="captcha">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/captcha.jpg">
                            </div>
                            <a class="c2a c2a-arw c2a--inline bg--nadkarniDarkCream fw--b c--nadkarniWhite hvr:bg--txt hvr:bg--nadkarniBlack hvr:c--nadkarniWhite size:less radius:expandedX2 uppercase" href="javascript:void(0)">
                                <span>Submit Your Requirement</span>
                            </a>
                        </div>
                    </form>
                </div>
                <div class="form__right flow-rootX2">
                    <div>
                        <figure><span class="material-icons-outlined">fmd_good</span></figure>
                        <article class="flow-rootx4">
                            <p class="h7 c--nadkarniGreen text-uppercase"><?php echo get_field('office_address_heading');?></p>
                            <p class="h7 fw--t"><?php echo get_field('office_address');?></p>
                        </article>
                    </div>
                    <div>
                        <figure><span class="material-icons-outlined">schedule</span></figure>
                        <article class="flow-rootx4">
                            <p class="h7 c--nadkarniGreen text-uppercase"><?php echo get_field('office_hours_heading');?></p>
                            <p class="h7 fw--t"><?php echo get_field('office_hours');?></p>
                        </article>
                    </div>
                    <div>
                        <figure><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/whatsapp.png"></figure>
                        <article class="flow-rootx4">
                            <p class="h7 c--nadkarniGreen text-uppercase"><?php echo get_field('office_whatsapp_heading');?></p>
                            <p class="h7 fw--t"><a href="tel:<?php echo get_field('office_whatsapp_number');?>" target="_blank">+91 <?php echo get_field('office_whatsapp_number');?></a> / <a href="tel:<?php echo get_field('office_alternate_whatsapp_number');?>" target="_blank"><?php echo get_field('office_alternate_whatsapp_number');?></a></p>
                        </article>
                    </div>
                    <div>
                        <figure><span class="material-icons-outlined">wifi_calling_3</span></figure>
                        <article class="flow-rootx4">
                            <p class="h7 c--nadkarniGreen text-uppercase">Office</p>
                            <p class="h7 fw--t"><a href="tel:<?php echo get_field('office_phone_number');?>" target="_blank">+91 <?php echo get_field('office_phone_number');?></a> / <a href="tel:<?php echo get_field('office_alternate_number');?>" target="_blank"><?php echo get_field('office_alternate_number');?></a></p>
                        </article>
                    </div>
                    <div>
                        <figure><span class="material-icons-outlined">wifi_calling_3</span></figure>
                        <article class="flow-rootx4">
                            <p class="h7 c--nadkarniGreen text-uppercase">Technical Support</p>
                            <p class="h7 fw--t"><a href="tel:<?php echo get_field('technical_support_number');?>" target="_blank">+91 <?php echo get_field('technical_support_number');?></a></p>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>
<?php get_footer(); ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/assets/js/frontend.js?v=<?php echo rand() ?>"></script>